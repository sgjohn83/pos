/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author sgjohn
 */
import java.io.*;
import java.util.*;

public class LicenseValidator {
    private static final String WHITELIST_FILE = "authorized_macs.txt";
    private static final String SECRET_CODE = "newmoon"; // Your secret code

    public static boolean isDeviceAuthorized() {
        String mac = MacAddressUtil.getMacAddress();
        Set<String> whitelist = loadWhitelist();
        return whitelist.contains(mac);
    }

    public static boolean authorizeDevice(String enteredCode) {
        if (enteredCode.equals(SECRET_CODE)) {
            String mac = MacAddressUtil.getMacAddress();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(WHITELIST_FILE, true))) {
                writer.write(mac);
                writer.newLine();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    private static Set<String> loadWhitelist() {
        Set<String> whitelist = new HashSet<>();
        File file = new File(WHITELIST_FILE);
        if (!file.exists()) return whitelist;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                whitelist.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return whitelist;
    }
}

