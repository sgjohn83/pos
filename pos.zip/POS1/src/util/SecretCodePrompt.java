/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author sgjohn
 */
import javax.swing.*;

public class SecretCodePrompt {
    public static String promptForSecretCode() {
        JPasswordField passwordField = new JPasswordField();
        Object[] message = {
            "Enter code to register this device:", passwordField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Device Authorization", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            return new String(passwordField.getPassword());
        }
        return null;
    }
}

