package service;

import model.SalesGSTReportItem;
import pos1.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SalesGSTReportService {

    private static final String REPORT_SQL
            = "SELECT invoice_number, sale_date, product_name, quantity, "
            + "ROUND(net_unit_price, 2) AS net_unit_price, "
            + "discount_pct, ROUND(discount_amt_per_unit, 2) AS discount_amt, "
            + "ROUND((net_unit_price - discount_amt_per_unit) * quantity, 2) AS taxable_value, "
            + "ROUND(((net_unit_price - discount_amt_per_unit) * quantity * tax_rate_pct/100), 2) AS total_tax, "
            + "ROUND((((net_unit_price - discount_amt_per_unit) * quantity * tax_rate_pct/100)/2), 2) AS cgst, "
            + "ROUND((((net_unit_price - discount_amt_per_unit) * quantity * tax_rate_pct/100)/2), 2) AS sgst, "
            + "ROUND((net_unit_price - discount_amt_per_unit) * (1 + tax_rate_pct/100), 2) AS gross_unit_price "
            + "FROM ("
            + "  SELECT s.invoice_number, s.sale_date, p.name AS product_name, "
            + "  COALESCE(si.quantity, 0) AS quantity, "
            + "  COALESCE(p.tax_rate, 18) AS tax_rate_pct, "
            + "  COALESCE(si.discount, 0) AS discount_pct, "
            + "  COALESCE(si.price, 0) / (1 + COALESCE(p.tax_rate, 18)/100) AS net_unit_price, "
            + "  (COALESCE(si.price, 0) / (1 + COALESCE(p.tax_rate, 18)/100)) * COALESCE(si.discount, 0)/100 AS discount_amt_per_unit "
            + "  FROM sales s "
            + "  JOIN sale_items si ON si.sale_id = s.id "
            + "  JOIN product p ON si.product_id = p.id "
            + "  WHERE (? IS NULL OR s.sale_date >= ?) "
            + "  AND (? IS NULL OR s.sale_date <= ?)"
            + "  AND p.is_taxable = 'YES' "
            + ") AS base "
            + "ORDER BY sale_date, invoice_number";

    public List<SalesGSTReportItem> getReportItems(LocalDate from, LocalDate to) throws SQLException {
        List<SalesGSTReportItem> items = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(REPORT_SQL)) {

            // Handle date parameters
            Date sqlFrom = (from != null) ? Date.valueOf(from) : null;
            Date sqlTo = (to != null) ? Date.valueOf(to.plusDays(1)) : null; // Make end date inclusive

            ps.setDate(1, sqlFrom);
            ps.setDate(2, sqlFrom);
            ps.setDate(3, sqlTo);
            ps.setDate(4, sqlTo);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    SalesGSTReportItem item = new SalesGSTReportItem();

                    // Set all fields with proper null handling
                    item.setInvoiceNumber(rs.getString("invoice_number"));

                    java.sql.Date saleDate = rs.getDate("sale_date");
                    if (saleDate != null) {
                        item.setSaleDate(saleDate.toLocalDate());
                    }

                    item.setProductName(rs.getString("product_name"));
                    item.setQuantity(rs.getBigDecimal("quantity"));
                    item.setNetUnitPrice(rs.getBigDecimal("net_unit_price"));
                    item.setDiscountPercent(rs.getBigDecimal("discount_pct"));
                    item.setDiscountAmount(rs.getBigDecimal("discount_amt"));
                    item.setTaxableValue(rs.getBigDecimal("taxable_value"));
                    item.setTotalTax(rs.getBigDecimal("total_tax"));
                    item.setCgst(rs.getBigDecimal("cgst"));
                    item.setSgst(rs.getBigDecimal("sgst"));
                    item.setGrossUnitPrice(rs.getBigDecimal("gross_unit_price"));

                    items.add(item);
                }
            }
        }
        return items;
    }
}
