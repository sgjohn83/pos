/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */


import java.math.BigDecimal;
import pos1.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FakeStockService {

    private final Connection conn;

    public FakeStockService() {
        this.conn = DBConnection.getConnection();
    }

    public List<Object[]> fetchStock(String brandName, String categoryName, String keyword) {
        List<Object[]> resultList = new ArrayList<>();

        StringBuilder sql = new StringBuilder(
            "SELECT p.sku, p.name AS product_name, c.name AS category_name, b.name AS brand_name, " +
            "s.quantity, p.price AS price, COALESCE(pi.discount, 0) AS discount " +
            "FROM stock s " +
            "JOIN product p ON s.product_id = p.id " +
            "JOIN brand b ON p.brand_id = b.id " +
            "JOIN category c ON p.category_id = c.id " +
            "LEFT JOIN ( " +
            "   SELECT pi1.product_id, pi1.cost_price, pi1.discount " +
            "   FROM purchase_items pi1 " +
            "   JOIN ( " +
            "       SELECT product_id, MAX(id) AS max_id " +
            "       FROM purchase_items " +
            "       GROUP BY product_id " +
            "   ) latest_pi ON pi1.product_id = latest_pi.product_id AND pi1.id = latest_pi.max_id " +
            ") pi ON pi.product_id = p.id " +
            "WHERE p.is_taxable = 'YES'" // Exclude non-taxable products
        );

        List<Object> params = new ArrayList<>();

        // Filter by Brand
        if (brandName != null && !brandName.trim().equalsIgnoreCase("All") && !brandName.trim().isEmpty()) {
            Integer brandId = getBrandIdByName(brandName.trim());
            if (brandId != null) {
                sql.append(" AND p.brand_id = ?");
                params.add(brandId);
            }
        }

        // Filter by Category
        if (categoryName != null && !categoryName.trim().equalsIgnoreCase("All") && !categoryName.trim().isEmpty()) {
            Integer categoryId = getCategoryIdByName(categoryName.trim());
            if (categoryId != null) {
                sql.append(" AND p.category_id = ?");
                params.add(categoryId);
            }
        }

        // Filter by Keyword
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (p.name LIKE ? OR p.sku LIKE ?)");
            String kw = "%" + keyword.trim() + "%";
            params.add(kw);
            params.add(kw);
        }

        try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String sku = rs.getString("sku");
                    String productName = rs.getString("product_name");
                    String category = rs.getString("category_name");
                    String brand = rs.getString("brand_name");
                    int quantity = rs.getInt("quantity");
                    double price = rs.getDouble("price");
                    
                    Integer productIdBySku = new ProductService(conn).getProductIdBySku(sku);
                    InventoryBatchService ivbService = new InventoryBatchService(conn);
                    InventoryBatchService.FifoResult p1 = ivbService.getFifoCostAndUpdateStock(productIdBySku, new BigDecimal(quantity), false);
                    if (p1.success) {
                        price = p1.totalCogs.doubleValue();
                    }
                    double discount = rs.getDouble("discount");

                    // Apply discount and tax
                    double discountedPrice = price - (price * discount / 100); // tax exclusive
                    double finalPriceWithTax = discountedPrice * 1.18;
                    double totalWithTax = finalPriceWithTax * quantity;

                    Object[] row = new Object[]{
                        sku,
                        productName,
                        category,
                        brand,
                        quantity,
                        round(price),
                        round(discount),
                        round(discountedPrice),
                        round(totalWithTax)
                    };

                    resultList.add(row);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch stock data", e);
        }

        return resultList;
    }

    private Integer getBrandIdByName(String name) {
        String sql = "SELECT id FROM brand WHERE name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Integer getCategoryIdByName(String name) {
        String sql = "SELECT id FROM category WHERE name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    public void upsertStock(int productId, BigDecimal quantity) throws SQLException {
        String sql = "INSERT INTO stock (product_id, quantity) " +
                     "VALUES (?, ?) " +
                     "ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity), last_updated = CURRENT_TIMESTAMP";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            stmt.setBigDecimal(2, quantity);
            stmt.executeUpdate();
        }
    }

    public void subtractStockQuantity(int productId, BigDecimal quantityToSubtract) throws SQLException {
        String checkSql = "SELECT quantity FROM stock WHERE product_id = ?";
        String updateSql = "UPDATE stock SET quantity = quantity - ? WHERE product_id = ?";

        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setInt(1, productId);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    BigDecimal currentQty = rs.getBigDecimal("quantity");

                    if (currentQty.compareTo(quantityToSubtract) < 0) {
                        throw new SQLException("Insufficient stock to subtract the requested quantity.");
                    }

                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setBigDecimal(1, quantityToSubtract);
                        updateStmt.setInt(2, productId);
                        updateStmt.executeUpdate();
                    }
                } else {
                    throw new SQLException("Stock entry not found for product_id: " + productId);
                }
            }
        }
    }
}
