package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Purchase;
import pos1.DBConnection;

public class FakePurchaseService {

    private Connection conn;

    public FakePurchaseService() {
        this.conn = DBConnection.getConnection();
    }

    // Check if invoice already exists
    public boolean doesInvoiceExist(String invoiceNumber) throws SQLException {
        String sql = "SELECT COUNT(*) FROM purchases WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, invoiceNumber.toUpperCase()); // make sure to check in uppercase
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        }
    }

    // Create a new purchase
    public boolean createPurchase(int supplierId, String invoiceNumber, Date purchaseDate, double totalAmount, int createdBy) throws SQLException {
        if (doesInvoiceExist(invoiceNumber)) {
            return false; // Invoice already exists, don't insert
        }

        String sql = "INSERT INTO purchases (supplier_id, invoice_number, purchase_date, total_amount, created_by) "
                   + "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, supplierId);
            stmt.setString(2, invoiceNumber.toUpperCase()); // enforce uppercase
            stmt.setDate(3, purchaseDate);
            stmt.setDouble(4, totalAmount);
            stmt.setInt(5, createdBy);
            return stmt.executeUpdate() > 0;
        }
    }

    // Get all invoice numbers
    public List<String> getAllInvoiceNumbers() throws SQLException {
        List<String> invoices = new ArrayList<>();
        String sql = "SELECT invoice_number FROM purchases";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                invoices.add(rs.getString("invoice_number"));
            }
        }
        return invoices;
    }

   public List<Object[]> getFilteredPurchases(Date fromDate, Date toDate, String supplierName, String searchKeyword) throws SQLException {
    List<Object[]> purchases = new ArrayList<>();

    if (fromDate == null) {
        fromDate = java.sql.Date.valueOf("1000-01-01");
    }
    if (toDate == null) {
        toDate = java.sql.Date.valueOf("9999-12-31");
    }

    StringBuilder sql = new StringBuilder(
        "SELECT DISTINCT s.name AS supplier_name, p.invoice_number, p.purchase_date, "
      + "p.total_amount, u.username AS created_by_username, p.created_at "
      + "FROM purchases p "
      + "JOIN supplier s ON p.supplier_id = s.id "
      + "LEFT JOIN user u ON p.created_by = u.id "
      + "JOIN purchase_items pi ON p.id = pi.purchase_id "
      + "JOIN product pr ON pi.product_id = pr.id "
      + "WHERE p.purchase_date BETWEEN ? AND ? "
      + "AND pr.is_taxable <> 'NO' "
    );

    boolean filterBySupplier = supplierName != null && !supplierName.trim().equalsIgnoreCase("All") && !supplierName.trim().equalsIgnoreCase("All Suppliers");
    boolean filterByKeyword = searchKeyword != null && !searchKeyword.trim().isEmpty();

    if (filterBySupplier) {
        sql.append("AND s.name = ? ");
    }

    if (filterByKeyword) {
        sql.append("AND p.invoice_number LIKE ? ");
    }

    sql.append("ORDER BY p.purchase_date ASC");

    try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql.toString())) {
        int index = 1;
        stmt.setDate(index++, new java.sql.Date(fromDate.getTime()));
        stmt.setDate(index++, new java.sql.Date(toDate.getTime()));

        if (filterBySupplier) {
            stmt.setString(index++, supplierName.trim());
        }

        if (filterByKeyword) {
            stmt.setString(index++, "%" + searchKeyword.trim() + "%");
        }

        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                purchases.add(new Object[]{
                    rs.getString("supplier_name"),
                    rs.getString("invoice_number"),
                    rs.getDate("purchase_date"),
                    rs.getBigDecimal("total_amount"),
                    rs.getString("created_by_username"),
                    rs.getTimestamp("created_at")
                });
            }
        }
    }

    return purchases;
}

    public List<Object[]> getPurchaseItemsForJTable(String invoiceNo) {
        List<Object[]> tableData = new ArrayList<>();
        String sql = "SELECT "
                   + "p.name AS product_name, "
                   + "b.name AS brand_name, "
                   + "c.name AS category_name, "
                   + "pi.product_id AS id, "
                   + "pi.quantity, "
                   + "pi.cost_price, "
                   + "pi.discount "
                   + "FROM purchase_items pi "
                   + "JOIN product p ON pi.product_id = p.id "
                   + "LEFT JOIN brand b ON p.brand_id = b.id "
                   + "JOIN category c ON p.category_id = c.id "
                   + "JOIN purchases po ON pi.purchase_id = po.id "
                   + "WHERE po.invoice_number = ? "
                   + "AND p.is_taxable != 'NO'";  // Exclude non-taxable products

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, invoiceNo);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] rowData = new Object[7];
                rowData[0] = rs.getString("product_name");
                rowData[1] = rs.getString("brand_name");
                rowData[2] = rs.getString("category_name");
                rowData[3] = rs.getInt("id");
                rowData[4] = rs.getDouble("quantity");
                rowData[5] = rs.getDouble("cost_price");
                rowData[6] = rs.getDouble("discount");
                tableData.add(rowData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tableData;
    }

    public int getPurchaseIdByInvoiceNumber(String invoiceNumber) throws SQLException {
        String sql = "SELECT id FROM purchases WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, invoiceNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        }
        return -1;
    }

    public boolean updateTotalAmountByInvoice(String invoiceNumber, double newTotalAmount) throws SQLException {
        String sql = "UPDATE purchases SET total_amount = ? WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, newTotalAmount);
            stmt.setString(2, invoiceNumber.toUpperCase());
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean addToTotalAmountByInvoice(String invoiceNumber, double additionalAmount) throws SQLException {
        String sql = "UPDATE purchases SET total_amount = total_amount + ? WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, additionalAmount);
            stmt.setString(2, invoiceNumber.toUpperCase());
            return stmt.executeUpdate() > 0;
        }
    }
}
