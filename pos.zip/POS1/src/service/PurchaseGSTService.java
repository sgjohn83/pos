package service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Date;          // JDBC Date
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import model.PurchaseGST;
import pos1.DBConnection;

public class PurchaseGSTService {

    private static final String BASE_SQL =
        "SELECT p.id AS purchaseId, p.invoice_number AS invoiceNumber, p.purchase_date AS purchaseDate, " +
        "s.name AS supplierName, pr.name AS productName, pi.quantity AS quantity, pi.cost_price AS costPrice, " +
        "pi.discount AS discount, ROUND((pi.quantity * pi.cost_price) - pi.discount, 2) AS taxableValue, " +
        "pr.tax_rate AS taxRate, " +
        "ROUND(((pi.quantity * pi.cost_price) - pi.discount) * (pr.tax_rate / 2 / 100), 2) AS cgstAmount, " +
        "ROUND(((pi.quantity * pi.cost_price) - pi.discount) * (pr.tax_rate / 2 / 100), 2) AS sgstAmount, " +
        "ROUND(((pi.quantity * pi.cost_price) - pi.discount) * (pr.tax_rate / 100), 2) AS totalTaxAmount, " +
        "ROUND(((pi.quantity * pi.cost_price) - pi.discount) * (1 + pr.tax_rate / 100), 2) AS totalValue " +
        "FROM purchases p " +
        "JOIN supplier s ON p.supplier_id = s.id " +
        "JOIN purchase_items pi ON pi.purchase_id = p.id " +
        "JOIN product pr ON pr.id = pi.product_id ";

    private static final String ORDER_BY = " ORDER BY p.purchase_date, p.invoice_number";

    public PurchaseGSTService() {
        // Optionally load configuration, connection pool, etc.
    }

    /** 
     * Fetches all purchases from the database.
     */
    public List<PurchaseGST> getAllPurchases() {
        return fetchPurchases(null, null);
    }

    /**
     * Fetches purchases between [fromDate] and [toDate], inclusive.
     * If either parameter is null, that bound is ignored.
     */
    public List<PurchaseGST> getPurchasesByDate(LocalDate fromDate, LocalDate toDate) {
        return fetchPurchases(fromDate, toDate);
    }

    /**
     * Internal helper that builds and executes the SQL, applying date filters if provided.
     */
    private List<PurchaseGST> fetchPurchases(LocalDate fromDate, LocalDate toDate) {
        List<PurchaseGST> purchases = new ArrayList<>();

        StringBuilder sql = new StringBuilder(BASE_SQL);
        // Apply date filters only if at least one bound is provided
         sql.append(" WHERE pr.is_taxable = 'YES' ");
        if (fromDate != null || toDate != null) {
          
            if (fromDate != null) {
                sql.append("AND  p.purchase_date >= ? ");
            }
            if (toDate != null) {
                if (fromDate != null) sql.append("AND ");
                sql.append("p.purchase_date <= ? ");
            }
        }
        sql.append(ORDER_BY);

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int idx = 1;
            if (fromDate != null) {
                ps.setDate(idx++, Date.valueOf(fromDate));
            }
            if (toDate != null) {
                ps.setDate(idx, Date.valueOf(toDate));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    PurchaseGST p = new PurchaseGST();
                    p.setPurchaseId(rs.getInt("purchaseId"));
                    p.setInvoiceNumber(rs.getString("invoiceNumber"));

                    Date sqlDate = rs.getDate("purchaseDate");
                    if (sqlDate != null) {
                        p.setPurchaseDate(sqlDate.toLocalDate());
                    }

                    p.setSupplierName(rs.getString("supplierName"));
                    p.setProductName(rs.getString("productName"));
                    p.setQuantity(rs.getBigDecimal("quantity"));
                    p.setCostPrice(rs.getBigDecimal("costPrice"));
                    p.setDiscount(rs.getBigDecimal("discount"));
                    p.setTaxableValue(rs.getBigDecimal("taxableValue"));
                    p.setTaxRate(rs.getBigDecimal("taxRate"));
                    p.setCgstAmount(rs.getBigDecimal("cgstAmount"));
                    p.setSgstAmount(rs.getBigDecimal("sgstAmount"));
                    p.setTotalTaxAmount(rs.getBigDecimal("totalTaxAmount"));
                    p.setTotalValue(rs.getBigDecimal("totalValue"));

                    purchases.add(p);
                }
            }

        } catch (SQLException ex) {
            // TODO: Replace with proper logging framework
            ex.printStackTrace();
        }

        return purchases;
    }
}
