/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Customer;
import pos1.DBConnection;

public class CustomerService {
    private Connection conn;

    public CustomerService() {
        this.conn = DBConnection.getConnection();
    }

    // Create a new customer
    public Customer addOrGetCustomer(Customer customer) {
    String checkSql = "SELECT * FROM customer WHERE name = ? AND phone = ?";
    String insertSql = "INSERT INTO customer (name, phone, email, address) VALUES (?, ?, ?, ?)";

    try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
        checkStmt.setString(1, customer.getName());
        checkStmt.setString(2, customer.getPhone());

        try (ResultSet rs = checkStmt.executeQuery()) {
            if (rs.next()) {
                // Customer exists, return the existing object
                Customer existing = new Customer();
                existing.setId(rs.getInt("id"));
                existing.setName(rs.getString("name"));
                existing.setPhone(rs.getString("phone"));
                existing.setEmail(rs.getString("email"));
                existing.setAddress(rs.getString("address"));
                return existing;
            }
        }

        // Insert new customer if not found
        try (PreparedStatement insertStmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
            insertStmt.setString(1, customer.getName());
            insertStmt.setString(2, customer.getPhone());
            insertStmt.setString(3, customer.getEmail());
            insertStmt.setString(4, customer.getAddress());

            int affectedRows = insertStmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = insertStmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        customer.setId(generatedKeys.getInt(1));
                        return customer;
                    }
                }
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return null; // if error or nothing inserted
}


    // Retrieve customer by ID
    public Customer getCustomerById(int id) {
        String sql = "SELECT * FROM customer WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToCustomer(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update a customer
    public boolean updateCustomer(Customer customer) {
        String sql = "UPDATE customer SET name = ?, phone = ?, email = ?, address = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getPhone());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getAddress());
            stmt.setInt(5, customer.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete a customer
    public boolean deleteCustomer(int id) {
        String sql = "DELETE FROM customer WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // List all customers
    public List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customer ORDER BY id DESC";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapResultSetToCustomer(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Utility method to map ResultSet to Customer
    private Customer mapResultSetToCustomer(ResultSet rs) throws SQLException {
        Customer customer = new Customer();
        customer.setId(rs.getInt("id"));
        customer.setName(rs.getString("name"));
        customer.setPhone(rs.getString("phone"));
        customer.setEmail(rs.getString("email"));
        customer.setAddress(rs.getString("address"));
        customer.setCreatedAt(rs.getTimestamp("created_at"));
        return customer;
    }
}
