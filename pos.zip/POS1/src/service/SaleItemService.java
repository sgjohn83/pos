/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */
import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import model.Product;
import model.SaleItem;

public class SaleItemService {
    private final Connection conn;

    public SaleItemService(Connection conn) {
        this.conn = conn;
    }

    // Insert a sale item
    public int insertSaleItem(SaleItem item) throws SQLException {
        String sql = "INSERT INTO sale_items (sale_id, product_id, quantity, price, tax_rate) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, item.getSale().getId());
            stmt.setInt(2, item.getProduct().getId());
            stmt.setBigDecimal(3, item.getQuantity());
            stmt.setBigDecimal(4, item.getPrice());
            stmt.setBigDecimal(5, item.getTaxRate());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Inserting sale item failed, no rows affected.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1); // return generated ID
                } else {
                    throw new SQLException("Inserting sale item failed, no ID obtained.");
                }
            }
        }
    }

   

}
