/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Brand;

public class BrandService {

    private Connection conn;

    // Constructor to initialize the connection
    public BrandService(Connection conn) {
        this.conn = conn;
    }

    // Add a new brand
    public boolean addBrand(Brand brand) throws SQLException {
        String sql = "INSERT INTO brand (name) VALUES (?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, brand.getName());
        int rows = ps.executeUpdate();
        ps.close();
        return rows > 0;
    }

    // Update an existing brand
    public boolean updateBrand(Brand brand) throws SQLException {
        String sql = "UPDATE brand SET name = ? WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, brand.getName());
        ps.setInt(2, brand.getId());
        int rows = ps.executeUpdate();
        ps.close();
        return rows > 0;
    }

    // Delete a brand
    public boolean deleteBrand(int id) throws SQLException {
        String sql = "DELETE FROM brand WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        int rows = ps.executeUpdate();
        ps.close();
        return rows > 0;
    }

    // Get a brand by ID
    public Brand getBrandById(int id) throws SQLException {
        String sql = "SELECT * FROM brand WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();

        Brand brand = null;
        if (rs.next()) {
            brand = new Brand(rs.getInt("id"), rs.getString("name"));
        }

        rs.close();
        ps.close();
        return brand;
    }

    // Get all brands
    public List<Brand> getAllBrands() throws SQLException {
        List<Brand> list = new ArrayList<Brand>();
        String sql = "SELECT * FROM brand ORDER BY name";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            Brand brand = new Brand(rs.getInt("id"), rs.getString("name"));
            list.add(brand);
        }

        rs.close();
        stmt.close();
        return list;
    }
      public Integer getBrandIdByName(String name) {
        String sql = "SELECT id FROM brand WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            } else {
                return null; // Brand not found
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}

