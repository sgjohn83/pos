package service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.InventoryBatch;

public class InventoryBatchService {

    private Connection connection;

    public InventoryBatchService(Connection connection) {
        this.connection = connection;
    }

    public static class FifoResult {

        public BigDecimal totalCogs;
        public BigDecimal totalDiscount;
        public boolean success;

        public FifoResult(BigDecimal totalCogs, BigDecimal totalDiscount, boolean success) {
            this.totalCogs = totalCogs;
            this.totalDiscount = totalDiscount;
            this.success = success;
        }
    }

public FifoResult getFifoCostAndUpdateStock(int productId, BigDecimal quantityToSell, boolean commit) {
    BigDecimal totalCogs = BigDecimal.ZERO;
    BigDecimal totalWeightedDiscount = BigDecimal.ZERO;
    BigDecimal totalQuantityUsed = BigDecimal.ZERO;
    BigDecimal remainingQuantityToSell = quantityToSell;
    boolean success = false;

    String selectBatchesSql = "SELECT id, quantity, cost_price, discount FROM inventory_batches "
            + "WHERE product_id = ? AND quantity > 0 ORDER BY created_at ASC";

    try (PreparedStatement selectStmt = connection.prepareStatement(selectBatchesSql)) {
        selectStmt.setInt(1, productId);
        ResultSet rs = selectStmt.executeQuery();

        while (rs.next() && remainingQuantityToSell.compareTo(BigDecimal.ZERO) > 0) {
            int batchId = rs.getInt("id");
            BigDecimal batchQuantity = rs.getBigDecimal("quantity");
            BigDecimal costPrice = rs.getBigDecimal("cost_price");
            BigDecimal discountPercent = rs.getBigDecimal("discount"); // Stored as percentage, e.g., 10 or 20

            BigDecimal quantityToUse = remainingQuantityToSell.min(batchQuantity);
            BigDecimal cogsForBatch = quantityToUse.multiply(costPrice);

            // Accumulate total COGS and weighted discount
            totalCogs = totalCogs.add(cogsForBatch);
            totalWeightedDiscount = totalWeightedDiscount.add(quantityToUse.multiply(discountPercent));
            totalQuantityUsed = totalQuantityUsed.add(quantityToUse);

            remainingQuantityToSell = remainingQuantityToSell.subtract(quantityToUse);

            // If commit is true, update batch quantity in DB
            if (commit) {
                String updateBatchSql = "UPDATE inventory_batches SET quantity = quantity - ? WHERE id = ?";
                try (PreparedStatement updateBatchStmt = connection.prepareStatement(updateBatchSql)) {
                    updateBatchStmt.setBigDecimal(1, quantityToUse);
                    updateBatchStmt.setInt(2, batchId);
                    updateBatchStmt.executeUpdate();
                }
            }

            // Debug batch-level info
            System.out.printf(
                "Batch %d → Used Qty: %s, Cost Price: %.2f, Discount%%: %.2f\n",
                batchId, quantityToUse.toPlainString(), costPrice.doubleValue(), discountPercent.doubleValue()
            );
        }

        success = remainingQuantityToSell.compareTo(BigDecimal.ZERO) == 0;

    } catch (SQLException e) {
        System.err.println("Error during FIFO calculation: " + e.getMessage());
        success = false;
    }

    // Final weighted average discount percentage (0–100%)
    BigDecimal effectiveDiscountPercent = BigDecimal.ZERO;
    if (totalQuantityUsed.compareTo(BigDecimal.ZERO) > 0) {
        effectiveDiscountPercent = totalWeightedDiscount
                .divide(totalQuantityUsed, 2, RoundingMode.HALF_UP); // 2 decimal places
    }

    // Debug final output
    System.out.println("Total COGS: " + totalCogs);
    System.out.println("Total Weighted Discount Sum: " + totalWeightedDiscount);
    System.out.println("Total Quantity Used: " + totalQuantityUsed);
    System.out.println("Effective Discount %: " + effectiveDiscountPercent);

    return new FifoResult(totalCogs, effectiveDiscountPercent, success);
}

    public List<InventoryBatch> getAllInventoryBatches() throws SQLException {
        List<InventoryBatch> batches = new ArrayList<>();
        String sql = "SELECT * FROM inventory_batches";

        try (Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                InventoryBatch batch = new InventoryBatch();
                batch.setId(rs.getInt("id"));
                batch.setProductId(rs.getInt("product_id"));
                batch.setPurchaseId(rs.getInt("purchase_id"));
                batch.setQuantity(rs.getBigDecimal("quantity"));
                batch.setCostPrice(rs.getBigDecimal("cost_price"));
                batch.setDiscount(rs.getBigDecimal("discount"));
                batch.setCreatedAt(rs.getTimestamp("created_at"));
                batches.add(batch);
            }
        }

        return batches;
    }

    public InventoryBatch getInventoryBatchById(int id) throws SQLException {
        InventoryBatch batch = null;
        String sql = "SELECT * FROM inventory_batches WHERE id = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                batch = new InventoryBatch();
                batch.setId(rs.getInt("id"));
                batch.setProductId(rs.getInt("product_id"));
                batch.setPurchaseId(rs.getInt("purchase_id"));
                batch.setQuantity(rs.getBigDecimal("quantity"));
                batch.setCostPrice(rs.getBigDecimal("cost_price"));
                batch.setDiscount(rs.getBigDecimal("discount"));
                batch.setCreatedAt(rs.getTimestamp("created_at"));
            }
        }

        return batch;
    }

    public boolean addInventoryBatches(List<InventoryBatch> batchList, Connection conn) {
        String sql = "INSERT INTO inventory_batches (product_id, purchase_id, quantity, cost_price, discount) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false); // Start transaction

            for (InventoryBatch batch : batchList) {
                ps.setInt(1, batch.getProductId());
                ps.setInt(2, batch.getPurchaseId());
                ps.setBigDecimal(3, batch.getQuantity());
                ps.setBigDecimal(4, batch.getCostPrice());
                ps.setBigDecimal(5, batch.getDiscount());
                ps.addBatch(); // Add to batch
            }

            int[] result = ps.executeBatch(); // Execute all inserts
            conn.commit(); // Commit transaction

            System.out.println("Inserted " + result.length + " inventory batches successfully.");
            return true;

        } catch (SQLException e) {
            try {
                conn.rollback(); // Rollback on error
                System.err.println("Transaction rolled back due to error: " + e.getMessage());
            } catch (SQLException rollbackEx) {
                System.err.println("Rollback failed: " + rollbackEx.getMessage());
            }
            return false;
        } finally {
            try {
                conn.setAutoCommit(true); // Restore default
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public boolean updateInventoryBatch(InventoryBatch batch) throws SQLException {
        String sql = "UPDATE inventory_batches SET product_id=?, purchase_id=?, quantity=?, cost_price=?, discount=? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, batch.getProductId());
            ps.setInt(2, batch.getPurchaseId());
            ps.setBigDecimal(3, batch.getQuantity());
            ps.setBigDecimal(4, batch.getCostPrice());
            ps.setBigDecimal(5, batch.getDiscount());
            ps.setInt(6, batch.getId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean deleteInventoryBatch(int id) throws SQLException {
        String sql = "DELETE FROM inventory_batches WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }
}
