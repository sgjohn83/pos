/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Purchase;
import pos1.DBConnection;

public class PurchaseService {

    private Connection conn;

    public PurchaseService() {
        this.conn = DBConnection.getConnection();
    }

    // Check if invoice already exists
    public boolean doesInvoiceExist(String invoiceNumber) throws SQLException {
        String sql = "SELECT COUNT(*) FROM purchases WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, invoiceNumber.toUpperCase()); // make sure to check in uppercase
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        }
    }

    // Create a new purchase
    public boolean createPurchase(int supplierId, String invoiceNumber, Date purchaseDate, double totalAmount, int createdBy) throws SQLException {
        if (doesInvoiceExist(invoiceNumber)) {
            return false; // Invoice already exists, don't insert
        }

        String sql = "INSERT INTO purchases (supplier_id, invoice_number, purchase_date, total_amount, created_by) "
                + "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, supplierId);
            stmt.setString(2, invoiceNumber.toUpperCase()); // enforce uppercase
            stmt.setDate(3, purchaseDate);
            stmt.setDouble(4, totalAmount);
            stmt.setInt(5, createdBy);
            return stmt.executeUpdate() > 0;
        }
    }

    // Get all invoice numbers
    public List<String> getAllInvoiceNumbers() throws SQLException {
        List<String> invoices = new ArrayList<>();
        String sql = "SELECT invoice_number FROM purchases";
        try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                invoices.add(rs.getString("invoice_number"));
            }
        }
        return invoices;
    }

    public List<Object[]> getFilteredPurchases(Date fromDate, Date toDate, String supplierName, String searchKeyword) throws SQLException {
        List<Object[]> purchases = new ArrayList<>();

        // Default full range for null dates
        if (fromDate == null) {
            fromDate = java.sql.Date.valueOf("1000-01-01");
            System.out.println("[DEBUG] fromDate was null, defaulting to: " + fromDate);
        }
        if (toDate == null) {
            toDate = java.sql.Date.valueOf("9999-12-31");
            System.out.println("[DEBUG] toDate was null, defaulting to: " + toDate);
        }

        StringBuilder sql = new StringBuilder(
                "SELECT s.name AS supplier_name, p.invoice_number, p.purchase_date, "
                + "p.total_amount, u.username AS created_by_username, p.created_at "
                + "FROM purchases p "
                + "JOIN supplier s ON p.supplier_id = s.id "
                + "LEFT JOIN user u ON p.created_by = u.id "
                + "WHERE p.purchase_date BETWEEN ? AND ?"
        );

        boolean useSupplierFilter = supplierName != null
                && !supplierName.trim().equalsIgnoreCase("All")
                && !supplierName.trim().equalsIgnoreCase("All Suppliers");

        if (useSupplierFilter) {
            sql.append(" AND s.name = ?");
        }

        if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
            sql.append(" AND p.invoice_number LIKE ?");
        }

        sql.append(" ORDER BY p.purchase_date ASC");

        System.out.println("[DEBUG] Final SQL: " + sql);

        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql.toString())) {
            int index = 1;
            stmt.setDate(index++, new java.sql.Date(fromDate.getTime()));
            stmt.setDate(index++, new java.sql.Date(toDate.getTime()));
            System.out.println("[DEBUG] Param 1 (from): " + fromDate);
            System.out.println("[DEBUG] Param 2 (to): " + toDate);

            if (useSupplierFilter) {
                stmt.setString(index++, supplierName);
                System.out.println("[DEBUG] Param " + (index - 1) + " (supplier): " + supplierName);
            }

            if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
                stmt.setString(index++, "%" + searchKeyword + "%");
                System.out.println("[DEBUG] Param " + (index - 1) + " (search): %" + searchKeyword + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                int rowCount = 0;
                while (rs.next()) {
                    Object[] row = new Object[]{
                        rs.getString("supplier_name"),
                        rs.getString("invoice_number"),
                        rs.getDate("purchase_date"),
                        rs.getBigDecimal("total_amount"),
                        rs.getString("created_by_username"),
                        rs.getTimestamp("created_at")
                    };
                    purchases.add(row);
                    rowCount++;
                }
                System.out.println("[DEBUG] Total rows fetched: " + rowCount);
            }
        }

        return purchases;
    }

    public List<Object[]> getPurchaseItemsForJTable(String invoiceNo) {
        List<Object[]> tableData = new ArrayList<>();
        String sql = "SELECT "
                + "p.name AS product_name, "
                + "b.name AS brand_name, "
                + "c.name AS category_name, "
                + "pi.product_id AS id, "
                + // Using product_id as sku as per your table structure
                "pi.quantity, "
                + "pi.cost_price, "
                + "pi.discount "
                + "FROM purchase_items pi "
                + "JOIN product p ON pi.product_id = p.id "
                + "LEFT JOIN brand b ON p.brand_id = b.id "
                + "JOIN category c ON p.category_id = c.id "
                + "JOIN purchases po ON pi.purchase_id = po.id "
                + "WHERE po.invoice_number = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, invoiceNo);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] rowData = new Object[7];
                rowData[0] = rs.getString("product_name");
                rowData[1] = rs.getString("brand_name");
                rowData[2] = rs.getString("category_name");
                rowData[3] = rs.getInt("id"); // Assuming product_id is used as SKU
                rowData[4] = rs.getDouble("quantity");
                rowData[5] = rs.getDouble("cost_price");
                rowData[6] = rs.getDouble("discount");
                tableData.add(rowData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (e.g., log it, show an error message)
        }

        return tableData;
    }

    public int getPurchaseIdByInvoiceNumber(String invoiceNumber) throws SQLException {
        String sql = "SELECT id FROM purchases WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, invoiceNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        }
        return -1; // not found
    }
    // Update total amount for a given invoice number

    public boolean updateTotalAmountByInvoice(String invoiceNumber, double newTotalAmount) throws SQLException {
        String sql = "UPDATE purchases SET total_amount = ? WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, newTotalAmount);
            stmt.setString(2, invoiceNumber.toUpperCase()); // Enforce uppercase to match stored format
            return stmt.executeUpdate() > 0;
        }
    }
    // Add to existing total amount for a given invoice number

    public boolean addToTotalAmountByInvoice(String invoiceNumber, double additionalAmount) throws SQLException {
        String sql = "UPDATE purchases SET total_amount = total_amount + ? WHERE invoice_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, additionalAmount);
            stmt.setString(2, invoiceNumber.toUpperCase()); // Ensure uppercase format
            return stmt.executeUpdate() > 0;
        }
    }

}
