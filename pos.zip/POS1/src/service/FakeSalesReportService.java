/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.SalesReport;
import model.SaleItemDetail;
import pos1.DBConnection;

public class FakeSalesReportService {

    /**
     * Fetches a list of SalesReport DTOs filtered by optional search text and
     * date range.
     * 
     * Price semantics:
     * - si.price: amount per unit including 18% tax, before discount
     * - si.discount: percent (1–100) off that price
     * - si.cogs: total cost for the entire quantity
     * 
     * Aggregations:
     * - totalQty: SUM(si.quantity)
     * - totalBeforeDiscount: SUM(si.price * si.quantity)
     * - totalDiscount: SUM(si.price * si.quantity * (si.discount/100))
     * - amountPaid: SUM(si.price * si.quantity * (1 - si.discount/100))
     * - taxAmount: SUM(si.price * si.quantity * (1 - si.discount/100) * (18.0/118.0))
     * - totalCostPrice: SUM(si.cogs)
     * - grossProfit: amountPaid_exTax - totalCostPrice
     *   where amountPaid_exTax = amountPaid * (1/1.18)
     */
    public List<SalesReport> getSalesReport(String searchText, Date fromDate, Date toDate) {
        List<SalesReport> reportList = new ArrayList<>();

        boolean hasSearch = searchText != null && !searchText.trim().isEmpty();
        boolean hasDateFilter = fromDate != null && toDate != null;

        StringBuilder sql = new StringBuilder();

        sql.append("SELECT ")
            .append("s.id AS saleId, ")
            .append("s.invoice_number AS invoiceNo, ")
            .append("DATE_FORMAT(s.sale_date, '%d-%m-%Y') AS saleDate, ")
            .append("COALESCE(c.name, 'Walk-in') AS customerName, ")
            .append("c.phone AS customerPhone, ")
            .append("SUM(si.quantity) AS totalQty, ")
            .append("ROUND(SUM(si.price * si.quantity * (100.0 / 118)), 2) AS totalBeforeDiscount, ")
            .append("ROUND(SUM(si.price * si.quantity * (si.discount / 100)), 2) AS totalDiscount, ")
            .append("ROUND(SUM(si.price * si.quantity * (1 - si.discount / 100) * (100.0 / 118)), 2) AS totalSales, ")
            .append("ROUND(SUM(si.price * si.quantity * (1 - si.discount / 100) * (18 / 118)), 2) AS taxAmount, ")
            .append("ROUND(SUM(si.price * si.quantity * (1 - si.discount / 100)), 2) AS amountPaid, ")
            .append("ROUND(SUM(si.cogs), 2) AS totalCostPrice, ")
            .append("ROUND(SUM(si.price * si.quantity * (1 - si.discount / 100)) - SUM(si.cogs), 2) AS grossProfit, ")
            .append("u.username AS soldBy ")
            .append("FROM sales s ")
            .append("LEFT JOIN sale_items si ON s.id = si.sale_id ")
            .append("LEFT JOIN product p ON si.product_id = p.id ")
            .append("LEFT JOIN customer c ON s.customer_id = c.id ")
            .append("INNER JOIN user u ON s.created_by = u.id ")
            .append("WHERE p.is_taxable <> 'NO' ");

        if (hasSearch) {
            sql.append("AND (s.invoice_number LIKE ? OR c.name LIKE ? OR c.phone LIKE ?) ");
        }
        if (hasDateFilter) {
            sql.append("AND DATE(s.sale_date) BETWEEN ? AND ? ");
        }

        sql.append("GROUP BY s.id ")
           .append("ORDER BY s.sale_date DESC, s.invoice_number");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            int idx = 1;
            if (hasSearch) {
                String like = "%" + searchText.trim() + "%";
                stmt.setString(idx++, like);
                stmt.setString(idx++, like);
                stmt.setString(idx++, like);
            }
            if (hasDateFilter) {
                stmt.setDate(idx++, fromDate);
                stmt.setDate(idx++, toDate);
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    SalesReport r = new SalesReport();
                    r.setInvoiceNo(rs.getString("invoiceNo"));
                    r.setSaleDate(rs.getString("saleDate"));
                    r.setCustomerName(rs.getString("customerName"));
                    r.setCustomerPhone(rs.getString("customerPhone"));
                    r.setTotalQty(rs.getBigDecimal("totalQty"));
                    r.setTotalBeforeDiscount(rs.getBigDecimal("totalBeforeDiscount"));
                    r.setTotalDiscount(rs.getBigDecimal("totalDiscount"));
                    r.setTotalSales(rs.getBigDecimal("totalSales"));
                    r.setTotalCostPrice(rs.getBigDecimal("totalCostPrice"));
                    r.setTaxAmount(rs.getBigDecimal("taxAmount"));
                    r.setAmountPaid(rs.getBigDecimal("amountPaid"));
                    r.setGrossProfit(rs.getBigDecimal("grossProfit"));
                    r.setSoldBy(rs.getString("soldBy"));
                    reportList.add(r);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Replace with logger in production
        }

        return reportList;
    }

    public List<SaleItemDetail> getSaleItemDetailsByInvoice(String invoiceNumber) {
        List<SaleItemDetail> saleItems = new ArrayList<>();

        String query = "SELECT "
                + " b.name AS brand_name, "
                + " p.name AS product_name, "
                + " c.name AS category_name, "
                + " si.quantity, "
                + " si.price "
                + "FROM sale_items si "
                + "JOIN product p ON si.product_id = p.id "
                + "LEFT JOIN brand b ON p.brand_id = b.id "
                + "JOIN category c ON p.category_id = c.id "
                + "JOIN sales s ON si.sale_id = s.id "
                + "WHERE s.invoice_number = ? AND p.is_taxable <> 'NO'";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, invoiceNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    SaleItemDetail item = new SaleItemDetail(
                            rs.getString("brand_name"),
                            rs.getString("product_name"),
                            rs.getString("category_name"),
                            rs.getDouble("quantity"),
                            rs.getDouble("price")
                    );
                    saleItems.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Replace with proper logging
        }

        return saleItems;
    }
}

