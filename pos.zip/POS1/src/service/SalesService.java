/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Sales;
import pos1.DBConnection;

public class SalesService {
    private Connection conn;

    public SalesService() {
        this.conn = DBConnection.getConnection();
    }

    // Insert a new sale
    public int insertSale(Sales sale) throws SQLException {
        String sql = "INSERT INTO sales (customer_id, invoice_number, sale_date, total_amount, discount, tax, net_amount, created_by) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setObject(1, sale.getCustomerId(), Types.INTEGER);
            stmt.setString(2, sale.getInvoiceNumber());
            stmt.setDate(3, sale.getSaleDate());
            stmt.setBigDecimal(4, sale.getTotalAmount());
            stmt.setBigDecimal(5, sale.getDiscount());
            stmt.setBigDecimal(6, sale.getTax());
            stmt.setBigDecimal(7, sale.getNetAmount());
            stmt.setObject(8, sale.getCreatedBy(), Types.INTEGER);

            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Inserting sale failed, no rows affected.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1); // return generated sale ID
                } else {
                    throw new SQLException("Inserting sale failed, no ID obtained.");
                }
            }
        }
    }

    // Get a sale by ID
    public Sales getSaleById(int id) throws SQLException {
        String sql = "SELECT * FROM sales WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractSale(rs);
                }
            }
        }
        return null;
    }

    // List all sales
    public List<Sales> getAllSales() throws SQLException {
        List<Sales> salesList = new ArrayList<>();
        String sql = "SELECT * FROM sales ORDER BY sale_date DESC";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                salesList.add(extractSale(rs));
            }
        }

        return salesList;
    }

    // Extract sale from ResultSet
    private Sales extractSale(ResultSet rs) throws SQLException {
        Sales sale = new Sales();
        sale.setId(rs.getInt("id"));
        sale.setCustomerId((Integer) rs.getObject("customer_id"));
        sale.setInvoiceNumber(rs.getString("invoice_number"));
        sale.setSaleDate(rs.getDate("sale_date"));
        sale.setTotalAmount(rs.getBigDecimal("total_amount"));
        sale.setDiscount(rs.getBigDecimal("discount"));
        sale.setTax(rs.getBigDecimal("tax"));
        sale.setNetAmount(rs.getBigDecimal("net_amount"));
        sale.setCreatedBy((Integer) rs.getObject("created_by"));
        sale.setCreatedAt(rs.getTimestamp("created_at"));
        return sale;
    }
}

