package service;

import java.sql.*;
import java.util.*;
import model.User;
import pos1.DBConnection;
import org.springframework.security.crypto.bcrypt.BCrypt;

public class UserService {

    public boolean addUser(User user) {
        String sql = "INSERT INTO user (username, password, role, status, created_at) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            String hashedPassword = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());

            stmt.setString(1, user.getUsername());
            stmt.setString(2, hashedPassword);
            stmt.setString(3, user.getRole());
            stmt.setBoolean(4, user.isStatus());
            stmt.setTimestamp(5, user.getCreatedAt());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public User getUserByUsername(String username) {
        String sql = "SELECT * FROM user WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                user.setStatus(rs.getBoolean("status"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                return user;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean authenticateUser(String username, String plainPassword) {
        User user = getUserByUsername(username);
        return user != null && BCrypt.checkpw(plainPassword, user.getPassword());
    }

    public boolean changePassword(int userId, String oldPassword, String newPassword) {
        String selectSql = "SELECT password FROM user WHERE id = ?";
        String updateSql = "UPDATE user SET password = ? WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {

            selectStmt.setInt(1, userId);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                String storedHashedPassword = rs.getString("password");

                // Check old password
                if (!BCrypt.checkpw(oldPassword, storedHashedPassword)) {
                    return false; // Old password does not match
                }

                // Hash new password
                String newHashedPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt());

                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setString(1, newHashedPassword);
                    updateStmt.setInt(2, userId);

                    return updateStmt.executeUpdate() > 0;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public int getUserCount() {
        String sql = "SELECT COUNT(*) FROM user";
        try (Connection conn = DBConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
   public boolean resetPasswordByUsername(String username) {
    String defaultPassword = "1234";
    String hashedPassword = BCrypt.hashpw(defaultPassword, BCrypt.gensalt());
    String sql = "UPDATE user SET password = ? WHERE username = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, hashedPassword);
        stmt.setString(2, username);

        return stmt.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace(); // Replace with logging
        return false;
    }
}

public List<User> getAllUsers() {
    List<User> users = new ArrayList<>();
    String sql = "SELECT * FROM user";

    try (Connection conn = DBConnection.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        while (rs.next()) {
            User user = new User();
            user.setId(rs.getInt("id"));
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password")); // Optionally skip this line
            user.setRole(rs.getString("role"));
            user.setStatus(rs.getBoolean("status"));
            user.setCreatedAt(rs.getTimestamp("created_at"));
            users.add(user);
        }

    } catch (SQLException e) {
        e.printStackTrace(); // Replace with logging
    }

    return users;
}


}
