package service;

import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import model.Product;
import pos1.DBConnection;

public class ProductService {

    private final Connection conn;

    public ProductService(Connection conn) {
        this.conn = conn;
    }

    // Add new product
    public boolean addProduct(Product p) throws SQLException {
        String sql = "INSERT INTO product (sku, barcode, name, hsn_code, category_id, brand_id, unit, price, is_taxable, tax_rate, status) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, p.getSku());
        ps.setString(2, p.getBarcode());
        ps.setString(3, p.getName());
        ps.setString(4, p.getHsnCode());
        ps.setInt(5, p.getCategoryId());

        if (p.getBrandId() != null) {
            ps.setInt(6, p.getBrandId());
        } else {
            ps.setNull(6, Types.INTEGER);
        }

        ps.setString(7, p.getUnit());
        ps.setBigDecimal(8, p.getPrice());
        ps.setString(9, p.getIsTaxable());
        ps.setBigDecimal(10, p.getTaxRate());
        ps.setString(11, p.getStatus());

        return ps.executeUpdate() > 0;
    }

    // Update existing product
    public boolean updateProduct(Product p) throws SQLException {
        String sql = "UPDATE product SET sku=?, barcode=?, name=?, hsn_code=?, category_id=?, brand_id=?, unit=?, price=?, is_taxable=?, tax_rate=?, status=? "
                   + "WHERE id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, p.getSku());
        ps.setString(2, p.getBarcode());
        ps.setString(3, p.getName());
        ps.setString(4, p.getHsnCode());
        ps.setInt(5, p.getCategoryId());

        if (p.getBrandId() != null) {
            ps.setInt(6, p.getBrandId());
        } else {
            ps.setNull(6, Types.INTEGER);
        }

        ps.setString(7, p.getUnit());
        ps.setBigDecimal(8, p.getPrice());
        ps.setString(9, p.getIsTaxable());
        ps.setBigDecimal(10, p.getTaxRate());
        ps.setString(11, p.getStatus());
        ps.setInt(12, p.getId());

        return ps.executeUpdate() > 0;
    }

    // Delete product by ID
    public boolean deleteProduct(int id) throws SQLException {
        String sql = "DELETE FROM product WHERE id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        return ps.executeUpdate() > 0;
    }

    // Get product by ID
    public Product getProductById(int id) throws SQLException {
        String sql = "SELECT * FROM product WHERE id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return mapResultSetToProduct(rs);
        }
        return null;
    }

    // Get all products
    public List<Product> getAllProducts() throws SQLException {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM product ORDER BY name";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            list.add(mapResultSetToProduct(rs));
        }
        return list;
    }

    // Utility method to convert ResultSet row to Product
    private Product mapResultSetToProduct(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setId(rs.getInt("id"));
        p.setSku(rs.getString("sku"));
        p.setBarcode(rs.getString("barcode"));
        p.setName(rs.getString("name"));
        p.setHsnCode(rs.getString("hsn_code"));
        p.setCategoryId(rs.getInt("category_id"));

        int brandId = rs.getInt("brand_id");
        p.setBrandId(rs.wasNull() ? null : brandId);

        p.setUnit(rs.getString("unit"));
        p.setPrice(rs.getBigDecimal("price"));
        p.setIsTaxable(rs.getString("is_taxable"));
        p.setTaxRate(rs.getBigDecimal("tax_rate"));
        p.setStatus(rs.getString("status"));
        p.setCreatedAt(rs.getTimestamp("created_at"));
        return p;
    }

    // Check if SKU already exists
    public boolean isSkuExists(String sku) throws SQLException {
        String sql = "SELECT id FROM product WHERE sku = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, sku);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }

    // Check if barcode already exists
    public boolean isBarcodeExists(String barcode) throws SQLException {
        String sql = "SELECT id FROM product WHERE barcode = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, barcode);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }

    // Get products by brand ID
    public List<Product> getProductsByBrandId(int brandId) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM product WHERE brand_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, brandId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Product product = mapResultSetToProduct(rs);
                products.add(product);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return products;
    }

    // Get product ID by name
    public Integer getProductIdByName(String name) {
        String sql = "SELECT id FROM product WHERE name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Get product ID by SKU
    public Integer getProductIdBySku(String sku) {
        String sql = "SELECT id FROM product WHERE sku = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sku);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
