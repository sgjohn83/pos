/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Category;

public class CategoryService {

    private final Connection conn;

    public CategoryService(Connection conn) {
        this.conn = conn;
    }

    // Add category
    public boolean addCategory(Category category) throws SQLException {
        String sql = "INSERT INTO category (name, description) VALUES (?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, category.getName());
        ps.setString(2, category.getDescription());
        return ps.executeUpdate() > 0;
    }

    // Update category
    public boolean updateCategory(Category category) throws SQLException {
        String sql = "UPDATE category SET name = ?, description = ? WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, category.getName());
        ps.setString(2, category.getDescription());
        ps.setInt(3, category.getId());
        return ps.executeUpdate() > 0;
    }

    // Delete category
    public boolean deleteCategory(int id) throws SQLException {
        String sql = "DELETE FROM category WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        return ps.executeUpdate() > 0;
    }

    // Get category by ID
    public Category getCategoryById(int id) throws SQLException {
        String sql = "SELECT * FROM category WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            Category c = new Category();
            c.setId(rs.getInt("id"));
            c.setName(rs.getString("name"));
            c.setDescription(rs.getString("description"));
            return c;
        }
        return null;
    }

    // Get all categories
    public List<Category> getAllCategories() throws SQLException {
        List<Category> list = new ArrayList<Category>();
        String sql = "SELECT * FROM category ORDER BY name";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Category c = new Category();
            c.setId(rs.getInt("id"));
            c.setName(rs.getString("name"));
            c.setDescription(rs.getString("description"));
            list.add(c);
        }
        return list;
    }

    // Check if name exists (for validation)
    public boolean isCategoryNameExists(String name) throws SQLException {
        String sql = "SELECT id FROM category WHERE name = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, name);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }
    
    public Integer getCategoryIdByName(String name) {
        String sql = "SELECT id FROM category WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            } else {
                return null; // Or throw exception if not found
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}

