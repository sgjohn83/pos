package service;

import java.sql.*;
import java.util.*;
import java.math.BigDecimal;
import model.PurchaseItem;
import pos1.DBConnection;

public final class PurchaseItemService {

    private final Connection conn;

    // Constructor with final field for immutable service class
    public PurchaseItemService() {
        this.conn = DBConnection.getConnection();
    }

    // 1. Insert multiple purchase items and return generated IDs
    public List<PurchaseItem> addPurchaseItems(List<PurchaseItem> items) throws SQLException {
        List<PurchaseItem> addedItems = new ArrayList<>();
        String sql = "INSERT INTO purchase_items (purchase_id, product_id, quantity, cost_price, discount) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            // Disable auto-commit for batch processing
            conn.setAutoCommit(false);

            for (PurchaseItem item : items) {
                stmt.setInt(1, item.getPurchaseId());
                stmt.setInt(2, item.getProductId());
                stmt.setBigDecimal(3, item.getQuantity());
                stmt.setBigDecimal(4, item.getCostPrice());
                stmt.setBigDecimal(5, item.getDiscount());
                stmt.addBatch();  // Add the insert to the batch
            }

            // Execute the batch of inserts
            int[] result = stmt.executeBatch();
            // Commit the transaction after the batch is executed
            conn.commit();

            // Retrieve generated keys (item IDs) for each inserted item
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                int i = 0;
                while (keys.next()) {
                    int generatedId = keys.getInt(1);
                    items.get(i).setId(generatedId);  // Set the generated ID for each item
                    addedItems.add(items.get(i));     // Add the item to the result list
                    i++;
                }
            }
        } catch (SQLException e) {
            // Rollback in case of an error
            conn.rollback();
            throw e;
        } finally {
            // Restore auto-commit behavior
            conn.setAutoCommit(true);
        }

        return addedItems;  // Return the list of PurchaseItem objects with generated IDs
    }

    // 2. Retrieve purchase items by purchase_id
    public List<PurchaseItem> getItemsByPurchaseId(int purchaseId) throws SQLException {
        List<PurchaseItem> itemList = new ArrayList<>();
        String sql = "SELECT * FROM purchase_items WHERE purchase_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, purchaseId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    PurchaseItem item = new PurchaseItem();
                    item.setId(rs.getInt("id"));            // Fetching the auto-generated ID
                    item.setPurchaseId(rs.getInt("purchase_id"));
                    item.setProductId(rs.getInt("product_id"));
                    item.setQuantity(rs.getBigDecimal("quantity"));
                    item.setCostPrice(rs.getBigDecimal("cost_price"));
                    item.setDiscount(rs.getBigDecimal("discount"));
                    itemList.add(item);
                }
            }
        }

        return itemList;
    }

    // 3. Delete purchase items by purchase_id
    public void deleteItemsByPurchaseId(int purchaseId) throws SQLException {
        String sql = "DELETE FROM purchase_items WHERE purchase_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, purchaseId);
            stmt.executeUpdate();
        }
    }

    // 4. Update a purchase item (if required)
    public void updatePurchaseItem(PurchaseItem item) throws SQLException {
        String sql = "UPDATE purchase_items SET quantity = ?, cost_price = ?, discount = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBigDecimal(1, item.getQuantity());
            stmt.setBigDecimal(2, item.getCostPrice());
            stmt.setBigDecimal(3, item.getDiscount());
            stmt.setInt(4, item.getId());
            stmt.executeUpdate();
        }
    }
    // 5. Fetch quantity by product_id and purchase_id

    public BigDecimal getQuantityByProductAndPurchaseId(int productId, int purchaseId) throws SQLException {
        String sql = "SELECT quantity FROM purchase_items WHERE product_id = ? AND purchase_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            stmt.setInt(2, purchaseId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal("quantity");
                } else {
                    return BigDecimal.ZERO;  // or null, based on your preference
                }
            }
        }
    }

}
