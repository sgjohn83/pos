/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author sgjohn
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import pos1.DBConnection;



import model.Supplier;


public class SupplierService {



    private Connection getConnection() throws SQLException {
        return DBConnection.getConnection();
    }

    // Save (insert or update)
    public void save(Supplier supplier) {
        if (supplier.getId() == 0) {
            insert(supplier);
        } else {
            update(supplier);
        }
    }

    // Insert
   public Supplier insert(Supplier supplier) {
    String sql = "INSERT INTO supplier (name, phone, email, address) VALUES (?, ?, ?, ?)";

    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

        stmt.setString(1, supplier.getName());
        stmt.setString(2, supplier.getPhone());
        stmt.setString(3, supplier.getEmail());
        stmt.setString(4, supplier.getAddress());
        stmt.executeUpdate();

        ResultSet keys = stmt.getGeneratedKeys();
        if (keys.next()) {
            int newId = keys.getInt(1);
            supplier.setId(newId);
        }

        String fetchCreatedAtSQL = "SELECT created_at FROM supplier WHERE id = ?";
        try (PreparedStatement fetchStmt = conn.prepareStatement(fetchCreatedAtSQL)) {
            fetchStmt.setInt(1, supplier.getId());
            ResultSet rs = fetchStmt.executeQuery();
            if (rs.next()) {
                supplier.setCreatedAt(rs.getTimestamp("created_at"));
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
        return null;
    }

    return supplier;
}


    // Update
    private void update(Supplier supplier) {
        String sql = "UPDATE supplier SET name = ?, phone = ?, email = ?, address = ? WHERE id = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, supplier.getName());
            stmt.setString(2, supplier.getPhone());
            stmt.setString(3, supplier.getEmail());
            stmt.setString(4, supplier.getAddress());
            stmt.setInt(5, supplier.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Find all
    public List<Supplier> findAll() {
        List<Supplier> suppliers = new ArrayList<>();
        String sql = "SELECT * FROM supplier";

        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Supplier s = new Supplier(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("address"),
                    rs.getTimestamp("created_at")
                );
                suppliers.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return suppliers;
    }

    // Find by ID
    public Supplier findById(int id) {
        Supplier supplier = null;
        String sql = "SELECT * FROM supplier WHERE id = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                supplier = new Supplier(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("address"),
                    rs.getTimestamp("created_at")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return supplier;
    }

    // Delete by ID
    public void deleteById(int id) {
        String sql = "DELETE FROM supplier WHERE id = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Check existence
    public boolean existsById(int id) {
        String sql = "SELECT COUNT(*) FROM supplier WHERE id = ?";
        boolean exists = false;

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                exists = rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return exists;
    }
     public List<Supplier> getAllSuppliers() throws SQLException {
        List<Supplier> list = new ArrayList<>();
        String query = "SELECT * FROM supplier";
          Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Supplier supplier = new Supplier(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("address"),
                    rs.getTimestamp("created_at")
                );
                list.add(supplier);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving suppliers: " + e.getMessage());
        }

        return list;
    }
     public Supplier getSupplierByName(String name) {
        Supplier supplier = null;
        String query = "SELECT * FROM supplier WHERE name = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    supplier = new Supplier();
                    supplier.setId(rs.getInt("id"));
                    supplier.setName(rs.getString("name"));
                    supplier.setPhone(rs.getString("phone"));
                    supplier.setEmail(rs.getString("email"));
                    supplier.setAddress(rs.getString("address"));
                    supplier.setCreatedAt(rs.getTimestamp("created_at"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return supplier; // Returns null if not found
    }
}
