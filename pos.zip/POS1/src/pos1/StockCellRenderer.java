package pos1;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public class StockCellRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
        JLabel cell = (JLabel) super.getTableCellRendererComponent(
            table, value, isSelected, hasFocus, row, column
        );

        cell.setHorizontalAlignment(SwingConstants.CENTER); // Center text
        cell.setFont(table.getFont());
        cell.setOpaque(true);

        try {
            int qtyCol = table.convertColumnIndexToView(4); // Quantity column
            int quantity = Integer.parseInt(table.getValueAt(row, qtyCol).toString());

            if (!isSelected) {
                if (quantity < 5) {
                    // Dark red background, white text
                    cell.setBackground(new Color(200, 0, 0));
                    cell.setForeground(Color.WHITE);
                    cell.setFont(cell.getFont().deriveFont(Font.BOLD));
                } else if (quantity < 10) {
                    // Warm amber background, dark text
                    cell.setBackground(new Color(255, 204, 102));
                    cell.setForeground(Color.BLACK);
                    cell.setFont(cell.getFont().deriveFont(Font.BOLD));
                } else {
                    // Soft green background for normal
                    cell.setBackground(new Color(220, 255, 220));
                    cell.setForeground(Color.BLACK);
                }
            } else {
                // Keep selection colors
                cell.setBackground(table.getSelectionBackground());
                cell.setForeground(table.getSelectionForeground());
            }
        } catch (Exception e) {
            // Fallback for non-numeric or other columns
            cell.setBackground(Color.WHITE);
            cell.setForeground(Color.BLACK);
        }

        return cell;
    }
}
