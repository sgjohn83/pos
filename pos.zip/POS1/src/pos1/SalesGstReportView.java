package pos1;

import com.formdev.flatlaf.FlatLightLaf;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.FileWriter;

/**
 * Swing UI for Sales GST Report, matching SQL output columns,
 * now with Export CSV built-in.
 */
public class SalesGstReportView extends JFrame {

    public JLabel lblTotalTaxableValue;
    public JLabel lblTotalCgst;
    public JLabel lblTotalSgst;
    public JLabel lblTotalTax;
    public JLabel lblTotalInvoiceValue;

    public JDateChooser fromDateChooser;
    public JDateChooser toDateChooser;
    public JTable table;
    public JButton btnGenerate;
    public JButton btnExportCsv;

    public SalesGstReportView() {
        // Setup FlatLaf look and feel
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setTitle("Sales GST Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);
        setContentPane(mainPanel);

        initFilterPanel(mainPanel);
        initTablePanel(mainPanel);
        initBottomContainer(mainPanel);

        // Attach export handler
        btnExportCsv.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportToCsv();
            }
        });

        setVisible(true);
    }

    private void initFilterPanel(JPanel parent) {
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        filterPanel.setBackground(Color.WHITE);

        fromDateChooser = new JDateChooser();
        fromDateChooser.setPreferredSize(new Dimension(160, 28));
        toDateChooser = new JDateChooser();
        toDateChooser.setPreferredSize(new Dimension(160, 28));

        btnGenerate = new JButton("Generate");
        styleButton(btnGenerate);

        filterPanel.add(createIconLabel("From:"));
        filterPanel.add(fromDateChooser);
        filterPanel.add(createIconLabel("To:"));
        filterPanel.add(toDateChooser);
        filterPanel.add(btnGenerate);

        parent.add(filterPanel, BorderLayout.NORTH);
    }

    private void initTablePanel(JPanel parent) {
        String[] columns = {
            "Invoice No", "Date", "Product", "Qty",
            "Net Price", "Discount %", "Discount Amt",
            "Taxable", "Tax", "CGST", "SGST", "Gross Price"
        };
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setRowHeight(28);
        table.setShowGrid(false);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setBackground(Color.WHITE);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        header.setBackground(new Color(33, 150, 243));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        scroll.getViewport().setBackground(Color.WHITE);

        parent.add(scroll, BorderLayout.CENTER);
    }

    private void initBottomContainer(JPanel parent) {
        JPanel bottomContainer = new JPanel(new BorderLayout());
        bottomContainer.setBackground(Color.WHITE);

        JPanel summaryPanel = new JPanel(new GridLayout(1, 5, 20, 5));
        summaryPanel.setBackground(new Color(245, 245, 245));
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        lblTotalTaxableValue = summaryLabelPanel("Total Taxable");
        lblTotalCgst         = summaryLabelPanel("Total CGST");
        lblTotalSgst         = summaryLabelPanel("Total SGST");
        lblTotalTax          = summaryLabelPanel("Total Tax");
        lblTotalInvoiceValue = summaryLabelPanel("Grand Total");

        summaryPanel.add(lblTotalTaxableValue);
        summaryPanel.add(lblTotalCgst);
        summaryPanel.add(lblTotalSgst);
        summaryPanel.add(lblTotalTax);
        summaryPanel.add(lblTotalInvoiceValue);

        JPanel exportPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        exportPanel.setBackground(Color.WHITE);
        exportPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        btnExportCsv = new JButton("Export CSV");
        styleButton(btnExportCsv);
        exportPanel.add(btnExportCsv);

        bottomContainer.add(summaryPanel, BorderLayout.CENTER);
        bottomContainer.add(exportPanel, BorderLayout.SOUTH);

        parent.add(bottomContainer, BorderLayout.SOUTH);
    }

    private JLabel summaryLabelPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 245, 245));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        titleLabel.setForeground(new Color(100, 100, 100));

        JLabel valueLabel = new JLabel("0.00", SwingConstants.CENTER);
        valueLabel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
        valueLabel.setForeground(new Color(33, 150, 243));

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);
        return valueLabel;
    }

    private JLabel createIconLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setIcon(UIManager.getIcon("OptionPane.informationIcon"));
        return label;
    }

    private void styleButton(JButton button) {
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        button.setBackground(new Color(33, 150, 243));
        button.setForeground(Color.WHITE);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
    }

    /**
     * Exports the current table model to a CSV file chosen by the user.
     */
    private void exportToCsv() {
        DefaultTableModel tm = (DefaultTableModel) table.getModel();
        if (tm.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No data to export.",
                                          "Export", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save CSV");
        chooser.setFileFilter(new FileNameExtensionFilter("CSV files", "csv"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            String path = chooser.getSelectedFile().getAbsolutePath();
            if (!path.toLowerCase().endsWith(".csv")) {
                path += ".csv";
            }
            try (FileWriter fw = new FileWriter(path)) {
                // write header
                for (int c = 0; c < tm.getColumnCount(); c++) {
                    fw.append(tm.getColumnName(c));
                    if (c < tm.getColumnCount() - 1) fw.append(',');
                }
                fw.append('\n');

                // write rows
                for (int r = 0; r < tm.getRowCount(); r++) {
                    for (int c = 0; c < tm.getColumnCount(); c++) {
                        Object val = tm.getValueAt(r, c);
                        fw.append(val != null ? val.toString() : "");
                        if (c < tm.getColumnCount() - 1) fw.append(',');
                    }
                    fw.append('\n');
                }

                JOptionPane.showMessageDialog(this,
                    "CSV exported to:\n" + path,
                    "Export Successful", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,
                    "Error exporting CSV:\n" + ex.getMessage(),
                    "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
