/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pos1;

/**
 *
 * @author sgjohn
 */
import java.awt.*;
import javax.swing.*;

public class Custom3DButton extends JButton {
    private static final int ARC = 20;
    private static final Color SHADOW_COLOR = new Color(0, 0, 0, 60);
    private static final int SHADOW_OFFSET = 3;

    public Custom3DButton(String text) {
        super(text);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setOpaque(false);
        setForeground(new Color(32, 33, 36));
        setFont(new Font("Segoe UI", Font.BOLD, 14));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    @Override
    protected void paintComponent(Graphics g) {
        int w = getWidth(), h = getHeight();
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);

        // Shadow
        g2.setColor(SHADOW_COLOR);
        g2.fillRoundRect(SHADOW_OFFSET, SHADOW_OFFSET,
                         w - SHADOW_OFFSET, h - SHADOW_OFFSET, ARC, ARC);

        // Gradient
        Color top, bottom;
        if (getModel().isPressed()) {
            top = new Color(200, 200, 200);
            bottom = new Color(170, 170, 170);
        } else if (getModel().isRollover()) {
            top = new Color(230, 230, 230);
            bottom = new Color(210, 210, 210);
        } else {
            top = new Color(245, 245, 245);
            bottom = new Color(220, 220, 220);
        }

        g2.setPaint(new GradientPaint(0, 0, top, 0, h, bottom));
        g2.fillRoundRect(0, 0, w - SHADOW_OFFSET, h - SHADOW_OFFSET, ARC, ARC);

        // Highlight
        g2.setStroke(new BasicStroke(1f));
        g2.setColor(new Color(255, 255, 255, 180));
        g2.drawRoundRect(1, 1, w - SHADOW_OFFSET - 3, (h - SHADOW_OFFSET) / 2, ARC, ARC);
        g2.setColor(new Color(0, 0, 0, 30));
        g2.drawRoundRect(1, (h - SHADOW_OFFSET) / 2, w - SHADOW_OFFSET - 3, (h - SHADOW_OFFSET) / 2, ARC, ARC);

        // Border
        g2.setColor(new Color(150, 150, 150));
        g2.drawRoundRect(0, 0, w - SHADOW_OFFSET, h - SHADOW_OFFSET, ARC, ARC);

        g2.dispose();
        super.paintComponent(g);
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        d.width += SHADOW_OFFSET;
        d.height += SHADOW_OFFSET;
        return d;
    }
}

