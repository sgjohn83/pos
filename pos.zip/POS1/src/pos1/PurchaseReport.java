package pos1;

import com.toedter.calendar.JDateChooser;
import controller.PurchaseReportController;
import controller.SupplierController;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;

public class PurchaseReport extends JFrame {

    public JPanel filterPanel, summaryPanel, rightSummaryPanel, detailTopButtonPanel;
    public JLabel fromLabel, toLabel, supplierLabel, searchLabel;
    public JLabel totalInvoicesLabel, totalAmountLabel, totalQuantityLabel;
    public JLabel detailTotalItemsLabel, detailTotalQtyLabel, detailTotalAmountLabel;
    public JDateChooser fromDateChooser, toDateChooser;
    public JComboBox<String> supplierComboBox;
    public JTextField searchField;
    public JButton searchButton, addItemButton, updateItemButton, deleteItemButton;
    public JTable summaryTable, detailTable;
    public JSplitPane splitPane;

    public PurchaseReport() {
        setTitle("Purchase Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        initUI();
        loadSupplierCombo();
    }

    private void initUI() {
        // === Filter Panel ===
        filterPanel = new JPanel(new GridBagLayout());
        filterPanel.setBorder(BorderFactory.createTitledBorder("Search Filters"));
        filterPanel.setBackground(new Color(245, 248, 255));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.anchor = GridBagConstraints.WEST;

        fromLabel = new JLabel("From:");
        toLabel = new JLabel("To:");
        supplierLabel = new JLabel("Supplier:");
        searchLabel = new JLabel("Search:");

        fromDateChooser = new JDateChooser();
        toDateChooser = new JDateChooser();

        supplierComboBox = new JComboBox<>(new String[]{"All Suppliers", "ABC Ltd", "XYZ Traders", "Global Inc"});
        searchField = new JTextField(15);

        searchButton = new JButton("Search");
        searchButton.setBackground(new Color(51, 102, 255));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);

        gbc.gridx = 0;
        gbc.gridy = 0;
        filterPanel.add(fromLabel, gbc);
        gbc.gridx = 1;
        filterPanel.add(fromDateChooser, gbc);
        gbc.gridx = 2;
        filterPanel.add(toLabel, gbc);
        gbc.gridx = 3;
        filterPanel.add(toDateChooser, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        filterPanel.add(supplierLabel, gbc);
        gbc.gridx = 1;
        filterPanel.add(supplierComboBox, gbc);
        gbc.gridx = 2;
        filterPanel.add(searchLabel, gbc);
        gbc.gridx = 3;
        filterPanel.add(searchField, gbc);
        gbc.gridx = 4;
        filterPanel.add(searchButton, gbc);

        add(filterPanel, BorderLayout.NORTH);

        // === Summary Table ===
        summaryTable = new JTable(new DefaultTableModel(
                new Object[]{"Supplier", "Invoice", "Date", "Total", "Created By", "Created At"}, 0
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });
        summaryTable.setRowSelectionAllowed(true);
        summaryTable.setSelectionBackground(new Color(184, 207, 229)); // light blue
        summaryTable.setSelectionForeground(Color.BLACK);
        summaryTable.setFocusable(true);

        summaryTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane summaryScroll = new JScrollPane(summaryTable);

        // === Detail Table ===
        detailTable = new JTable(new DefaultTableModel(
                new Object[]{"Product Name", "Brand Name", "Category", "Id", "Quantity", "Cost", "Discount", "Subtotal"}, 0
        ) {
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        });

        detailTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // === Buttons Above Detail Table ===
        addItemButton = new JButton("Add Item");
        updateItemButton = new JButton("Update Item");
        deleteItemButton = new JButton("Delete Item");

        detailTopButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        detailTopButtonPanel.add(addItemButton);
        detailTopButtonPanel.add(updateItemButton);
        detailTopButtonPanel.add(deleteItemButton);

        updateItemButton.addActionListener(e -> {
            int selectedRow = detailTable.getSelectedRow();
            if (selectedRow >= 0) {
                Object sku = detailTable.getValueAt(selectedRow, 3);
                JOptionPane.showMessageDialog(this, "Update Item for SKU: " + sku);
                // Controller or dialog logic here
            }
        });

        JPanel detailPanel = new JPanel(new BorderLayout());
        detailPanel.add(detailTopButtonPanel, BorderLayout.NORTH);
        detailPanel.add(new JScrollPane(detailTable), BorderLayout.CENTER);

        rightSummaryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        rightSummaryPanel.setBackground(new Color(245, 245, 255));

        detailTotalItemsLabel = createCard("Total Items", "0");
        detailTotalQtyLabel = createCard("Total Quantity", "0");
        detailTotalAmountLabel = createCard("Total Amount", "0.00");

        rightSummaryPanel.add(detailTotalItemsLabel);
        rightSummaryPanel.add(detailTotalQtyLabel);
        rightSummaryPanel.add(detailTotalAmountLabel);

        detailPanel.add(rightSummaryPanel, BorderLayout.SOUTH);

        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, summaryScroll, detailPanel);
        splitPane.setDividerLocation(500);
        splitPane.setResizeWeight(0.5);

        add(splitPane, BorderLayout.CENTER);

        // === Bottom Summary Panel ===
        summaryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        summaryPanel.setBackground(new Color(235, 245, 235));
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        totalInvoicesLabel = createCard("Total Invoices", "0");
        totalAmountLabel = createCard("Total Amount", "0.00");
        // totalQuantityLabel = createCard("Total Quantity", "0");

        summaryPanel.add(totalInvoicesLabel);
        summaryPanel.add(totalAmountLabel);
        //  summaryPanel.add(totalQuantityLabel);

        add(summaryPanel, BorderLayout.SOUTH);

        searchButton.addActionListener(e -> {
            new PurchaseReportController(PurchaseReport.this);
        });
    }

    private JLabel createCard(String title, String value) {
        JLabel label = new JLabel("<html><div style='text-align:center;'><b>" + title + "</b><br>" + value + "</div></html>");
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        label.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180)),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        return label;
    }

    public void updateSummaryLabels(int invoices, double amount, int quantity) {
        totalInvoicesLabel.setText(formatCard("Total Invoices", String.valueOf(invoices)));
        totalAmountLabel.setText(formatCard("Total Amount", String.format("%.2f", amount)));
        // totalQuantityLabel.setText(formatCard("Total Quantity", String.valueOf(quantity)));
    }

    public void updateDetailLabels(int items, int qty, double total) {
        detailTotalItemsLabel.setText(formatCard("Total Items", String.valueOf(items)));
        detailTotalQtyLabel.setText(formatCard("Total Quantity", String.valueOf(qty)));
        detailTotalAmountLabel.setText(formatCard("Total Amount", String.format("%.2f", total)));
    }

    public void computeDetailSummary() {
        DefaultTableModel model = (DefaultTableModel) detailTable.getModel();
        int itemCount = model.getRowCount();
        int totalQty = 0;
        double totalAmount = 0;

        for (int i = 0; i < itemCount; i++) {
            Object qtyObj = model.getValueAt(i, 4);
            Object subtotalObj = model.getValueAt(i, 7);
            int qty = qtyObj != null ? Integer.parseInt(qtyObj.toString()) : 0;
            double subtotal = subtotalObj != null ? Double.parseDouble(subtotalObj.toString()) : 0.0;
            totalQty += qty;
            totalAmount += subtotal;
        }

        updateDetailLabels(itemCount, totalQty, totalAmount);
    }

    public void computeInvoiceSummary() {
        DefaultTableModel model = (DefaultTableModel) summaryTable.getModel();
        int invoiceCount = model.getRowCount();
        double totalAmount = 0;
        int totalQuantity = 0;

        for (int i = 0; i < invoiceCount; i++) {
            Object amountObj = model.getValueAt(i, 3); // assuming "Total" is at column index 3
            Object qtyObj = model.getValueAt(i, 5);    // if you have quantity column, adjust index accordingly

            double amount = 0;
            int quantity = 0;

            try {
                amount = amountObj != null ? Double.parseDouble(amountObj.toString()) : 0.0;
            } catch (NumberFormatException e) {
                amount = 0.0;
            }

            try {
                quantity = qtyObj != null ? Integer.parseInt(qtyObj.toString()) : 0;
            } catch (NumberFormatException e) {
                quantity = 0;
            }

            totalAmount += amount;
            totalQuantity += quantity;
        }

        updateSummaryLabels(invoiceCount, totalAmount, totalQuantity);
    }

    private String formatCard(String title, String value) {
        return "<html><div style='text-align:center;'><b>" + title + "</b><br>" + value + "</div></html>";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PurchaseReport().setVisible(true));
    }

    private void loadSupplierCombo() {
        supplierComboBox.removeAllItems();

        new SupplierController().loadSuppliers(supplierComboBox); // Keep existing logic

        // Remove any empty or null entries
        for (int i = supplierComboBox.getItemCount() - 1; i >= 0; i--) {
            Object item = supplierComboBox.getItemAt(i);
            if (item == null || item.toString().trim().isEmpty()) {
                supplierComboBox.removeItemAt(i);
            }
        }

        // Add "All" at the top if not already present
        supplierComboBox.insertItemAt("All", 0);
        supplierComboBox.setSelectedIndex(0); // Optional: auto-select "All"
    }

}

