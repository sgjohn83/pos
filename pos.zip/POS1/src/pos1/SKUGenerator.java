package pos1;

import java.sql.*;

public class SKUGenerator {

    private Connection conn;

    public SKUGenerator() {
        this.conn = DBConnection.getConnection();
    }

    /**
     * Generates or retrieves an SKU based on brand, category, and product name.
     * @param brandName the brand name
     * @param categoryName the category name
     * @param productName the product name
     * @return the existing or newly generated SKU
     * @throws SQLException if database access error occurs
     */
    public String generateSKU(String brandName, String categoryName, String productName) throws SQLException {
        if (brandName == null || brandName.isEmpty()
                || categoryName == null || categoryName.isEmpty()
                || productName == null || productName.isEmpty()) {
            return ""; // or throw an IllegalArgumentException
        }

        // Check if product already exists by name, brand, and category
        String existingSKU = findExistingSKU(brandName, categoryName, productName);
        if (existingSKU != null) {
            return existingSKU;
        }

        // Otherwise, generate a new SKU
        String brandCode = brandName.substring(0, 3).toUpperCase();
        String categoryCode = categoryName.substring(0, 3).toUpperCase();
        String productCode = productName.substring(0, 3).toUpperCase();

        int suffix = 1;
        String sku;

        do {
            sku = String.format("%s-%s-%s-%04d", brandCode, categoryCode, productCode, suffix);
            suffix++;
        } while (skuExists(sku));

        return sku;
    }

    /**
     * Checks if a product exists with the given name, brand, and category.
     * @return the existing SKU if found, otherwise null.
     */
    private String findExistingSKU(String brandName, String categoryName, String productName) throws SQLException {
        String sql = "SELECT p.sku FROM product p " +
                     "JOIN brand b ON p.brand_id = b.id " +
                     "JOIN category c ON p.category_id = c.id " +
                     "WHERE p.name = ? AND b.name = ? AND c.name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, productName);
            ps.setString(2, brandName);
            ps.setString(3, categoryName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("sku");
                }
            }
        }
        return null;
    }

    /**
     * Checks if a SKU already exists in the product table.
     */
    private boolean skuExists(String sku) throws SQLException {
        String sql = "SELECT COUNT(*) FROM product WHERE sku = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sku);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }
}
