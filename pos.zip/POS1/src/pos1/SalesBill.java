/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pos1;

/**
 *
 * @author sgjohn
 */
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SalesBill{

    private Connection conn;

    public SalesBill() {
        this.conn = DBConnection.getConnection();
    }

    public String generateSalesBillNo() throws SQLException {
        String datePart = new SimpleDateFormat("yyyyMMdd").format(new Date());
        String prefix = "SB-" + datePart + "-";

        // Get the highest sequence number for today
        String sql = "SELECT invoice_number FROM sales WHERE invoice_number LIKE ? ORDER BY invoice_number DESC LIMIT 1";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, prefix + "%");
        ResultSet rs = stmt.executeQuery();

        int sequence = 1;

        if (rs.next()) {
            String lastInvoice = rs.getString("invoice_number");
            String[] parts = lastInvoice.split("-");
            sequence = Integer.parseInt(parts[2]) + 1;
        }

        String billNo = String.format("%s%04d", prefix, sequence);
        return billNo;
    }
}
