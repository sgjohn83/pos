package pos1;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.util.JRLoader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Map;

public class ReportPrinter {

    /**
     * Prints a Jasper report with the given parameters.
     *
     * @param jasperFilePath The path to the compiled .jasper file.
     * @param parameters A map of parameters to pass to the report.
     */
    public static void printReport(String jasperFilePath, Map<String, Object> parameters) {
        Connection conn = null;
        try {
            // Load the compiled Jasper report
            JasperReport report = (JasperReport) JRLoader.loadObjectFromFile(jasperFilePath);

            // Establish a DB connection
            conn = DBConnection.getConnection();

            // Fill the report with data from the DB and parameters
            JasperPrint print = JasperFillManager.fillReport(report, parameters, conn);

            // Display the report in a viewer
            JasperViewer viewer = new JasperViewer(print, false); // 'false' prevents automatic app exit
            viewer.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
            viewer.setVisible(true);

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // Close DB connection safely
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (Exception ignore) {
            }
        }
    }
}
