/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pos1;

/**
 *
 * @author sgjohn
 */


import model.User;

public class UserManager {

    private static UserManager instance;
    private User currentUser;

    // Private constructor to prevent external instantiation
    private UserManager() {
    }

    // Global access point to the single instance
    public static synchronized UserManager getInstance() {
        if (instance == null) {
            instance = new UserManager();
        }
        return instance;
    }

    // Set the currently logged-in user
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    // Get the currently logged-in user
    public User getCurrentUser() {
        return currentUser;
    }

    // Clear current user (logout)
    public void clearCurrentUser() {
        currentUser = null;
    }

    // Optional: get logged-in user's ID safely
    public int getUserId() {
        return currentUser != null ? currentUser.getId() : -1;
    }
}

