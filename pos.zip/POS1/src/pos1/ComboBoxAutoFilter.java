/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pos1;

/**
 *
 * @author sgjohn
 */
import javax.swing.*;
import java.util.Arrays;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Vector;

public class ComboBoxAutoFilter {
    private static boolean isAdjusting = false;

    public static void enable(JComboBox<String> comboBox) {
        comboBox.setEditable(true);
        JTextField editor = (JTextField) comboBox.getEditor().getEditorComponent();

        // Copy original items
        Vector<String> originalItems = new Vector<>();
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            originalItems.add(comboBox.getItemAt(i));
        }

        editor.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filter(); }
            public void removeUpdate(DocumentEvent e) { filter(); }
            public void changedUpdate(DocumentEvent e) {}

            private void filter() {
                if (isAdjusting) return;

                SwingUtilities.invokeLater(() -> {
                    String text = editor.getText();
                    Vector<String> filtered = new Vector<>();

                    for (String item : originalItems) {
                        if (item.toLowerCase().contains(text.toLowerCase())) {
                            filtered.add(item);
                        }
                    }

                    // If no match, optionally keep the text as-is
                    if (filtered.isEmpty()) {
                        filtered.add(text); // or skip this if undesired
                    }

                    isAdjusting = true;
                    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(filtered);
                    comboBox.setModel(model);
                    comboBox.setSelectedItem(text);
                    
                    if (comboBox.isShowing()) {
    comboBox.setPopupVisible(true);
}

                    
                    isAdjusting = false;
                });
            }
        });

        // Handle ENTER key
        editor.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && comboBox.getSelectedItem() != null) {
                    isAdjusting = true;
                    editor.setText(comboBox.getSelectedItem().toString());
                    comboBox.setPopupVisible(false);
                    isAdjusting = false;
                }
            }
        });
    }

    // Demo for testing

}

