package pos1;

import com.formdev.flatlaf.FlatLightLaf;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class PurchaseGstReportView extends JFrame {

    public JLabel lblTotalTaxableValue;
    public JLabel lblTotalCgst;
    public JLabel lblTotalSgst;
    public JLabel lblTotalTax;
    public JLabel lblTotalInvoiceValue;

    public JDateChooser fromDateChooser;
    public JDateChooser toDateChooser;
    public JTable table;
    public JButton btnGenerate;
    public JButton btnExportCsv;

    public PurchaseGstReportView() {
        // Set modern look and feel
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setTitle("Purchase GST Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);
        setContentPane(mainPanel);

        initFilterPanel(mainPanel);
        initTablePanel(mainPanel);
        initBottomContainer(mainPanel);

        setVisible(true);
        
     
    }

    private void initFilterPanel(JPanel parent) {
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        filterPanel.setBackground(Color.WHITE);

        fromDateChooser = new JDateChooser();
        fromDateChooser.setPreferredSize(new Dimension(160, 28));
        toDateChooser = new JDateChooser();
        toDateChooser.setPreferredSize(new Dimension(160, 28));

        btnGenerate = new JButton("Generate");
        styleButton(btnGenerate);

        filterPanel.add(createIconLabel("calendar_today", "From:"));
        filterPanel.add(fromDateChooser);
        filterPanel.add(createIconLabel("calendar_today", "To:"));
        filterPanel.add(toDateChooser);
        filterPanel.add(btnGenerate);

        parent.add(filterPanel, BorderLayout.NORTH);
    }

    private void initTablePanel(JPanel parent) {
        String[] columns = {"Invoice No", "Date", "Supplier", "Product", "Qty", "Cost", "Discount", "Taxable", "Tax Rate", "CGST", "SGST", "Tax", "Total"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setRowHeight(28);
        table.setShowGrid(false);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setBackground(Color.WHITE);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        header.setBackground(new Color(33, 150, 243));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        scroll.getViewport().setBackground(Color.WHITE);

        parent.add(scroll, BorderLayout.CENTER);
    }

    private void initBottomContainer(JPanel parent) {
        JPanel bottomContainer = new JPanel(new BorderLayout());
        bottomContainer.setBackground(Color.WHITE);

        // Summary Panel
        JPanel summaryPanel = new JPanel(new GridLayout(1, 5, 20, 5));
        summaryPanel.setBackground(new Color(245, 245, 245));
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        lblTotalTaxableValue = summaryLabelPanel("Total Taxable");
        lblTotalCgst = summaryLabelPanel("Total CGST");
        lblTotalSgst = summaryLabelPanel("Total SGST");
        lblTotalTax = summaryLabelPanel("Total Tax");
        lblTotalInvoiceValue = summaryLabelPanel("Grand Total");

        summaryPanel.add(lblTotalTaxableValue);
        summaryPanel.add(lblTotalCgst);
        summaryPanel.add(lblTotalSgst);
        summaryPanel.add(lblTotalTax);
        summaryPanel.add(lblTotalInvoiceValue);

        // Export Panel
        JPanel exportPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        exportPanel.setBackground(Color.WHITE);
        exportPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        btnExportCsv = new JButton("Export CSV");
        styleButton(btnExportCsv);
        exportPanel.add(btnExportCsv);

        bottomContainer.add(summaryPanel, BorderLayout.CENTER);
        bottomContainer.add(exportPanel, BorderLayout.SOUTH);

        parent.add(bottomContainer, BorderLayout.SOUTH);
    }

    private JLabel summaryLabelPanel(String title) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(245, 245, 245));

    JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
    titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
    titleLabel.setForeground(new Color(100, 100, 100));

    // Use the Unicode escape \u20B9 for the rupee symbol:
    JLabel valueLabel = new JLabel("0.00", SwingConstants.CENTER);
    valueLabel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
    valueLabel.setForeground(new Color(33, 150, 243));

    panel.add(titleLabel, BorderLayout.NORTH);
    panel.add(valueLabel, BorderLayout.CENTER);
    return valueLabel;
}

    private JLabel createIconLabel(String iconName, String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setIcon(UIManager.getIcon("OptionPane.informationIcon")); // Placeholder icon
        return label;
    }

    private void styleButton(JButton button) {
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        button.setBackground(new Color(33, 150, 243));
        button.setForeground(Color.WHITE);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
    }

}