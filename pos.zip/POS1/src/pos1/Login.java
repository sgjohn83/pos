package pos1;

import com.formdev.flatlaf.FlatLightLaf;
import model.User;
import service.UserService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.IOException;
import java.net.ServerSocket;
import util.LicenseValidator;
import util.SecretCodePrompt;

public class Login extends JFrame {

    private static ServerSocket lockSocket;

    public JTextField userNameTxt;
    public JPasswordField passwordTxt;
    public JButton submitButton;
    public JLabel messageLabel;

    public Login() {
        // Apply FlatLaf for a modern look
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setTitle("POS Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setUndecorated(true);
        initComponents();
        pack();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        // Main container with custom background
        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(Color.WHITE);
        container.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true));
        add(container);

        // Header
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER));
        header.setBackground(new Color(33, 150, 243));
        JLabel title = new JLabel("Welcome to SRI SAI ENTERPRISES");
        title.setFont(new Font("Segoe UI Semibold", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        header.add(title);
        container.add(header, BorderLayout.NORTH);

        // Form panel
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(20, 40, 20, 40));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(8, 0, 8, 0);

        JLabel userLabel = new JLabel("Username");
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gc.gridx = 0;
        gc.gridy = 0;
        form.add(userLabel, gc);

        userNameTxt = new JTextField(20);
        userNameTxt.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gc.gridy = 1;
        form.add(userNameTxt, gc);

        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gc.gridy = 2;
        form.add(passLabel, gc);

        passwordTxt = new JPasswordField(20);
        passwordTxt.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gc.gridy = 3;
        form.add(passwordTxt, gc);

        submitButton = new JButton("Login");
        submitButton.setFont(new Font("Segoe UI Semibold", Font.BOLD, 14));
        submitButton.setBackground(new Color(33, 150, 243));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        gc.gridy = 4;
        form.add(submitButton, gc);

        messageLabel = new JLabel(" ", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        messageLabel.setForeground(Color.RED);
        gc.gridy = 5;
        form.add(messageLabel, gc);

        container.add(form, BorderLayout.CENTER);

        // Footer with close icon
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setBackground(Color.WHITE);
        JButton closeBtn = new JButton("X");
        closeBtn.setFont(new Font("Segoe UI Semibold", Font.BOLD, 14));
        closeBtn.setBorder(null);
        closeBtn.setContentAreaFilled(false);
        closeBtn.setForeground(new Color(150, 150, 150));
        closeBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        closeBtn.addActionListener(e -> System.exit(0));
        footer.add(closeBtn);
        container.add(footer, BorderLayout.SOUTH);

        submitButton.addActionListener(e -> handleLogin());
        getRootPane().setDefaultButton(submitButton);
    }

    private void handleLogin() {
       TrialManager.resetTrial();        //For development and testing purpose
        if (!LicenseValidator.isDeviceAuthorized()) {
            String input = SecretCodePrompt.promptForSecretCode();
            if (input == null || !LicenseValidator.authorizeDevice(input)) {
                JOptionPane.showMessageDialog(null, "Invalid or unauthorized device.", "Access Denied", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            }
        }

        if (!TrialManager.isTrialValid()) {
            JOptionPane.showMessageDialog(this, "Application Error", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }

        UserService userService = new UserService();
        if (userService.getUserCount() == 0) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("1234");
            admin.setRole("admin");
            admin.setStatus(true);
            admin.setCreatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
            userService.addUser(admin);
        }

        String username = userNameTxt.getText().trim();
        String password = new String(passwordTxt.getPassword());
        if (username.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Username and password required.");
            return;
        }

        boolean auth = userService.authenticateUser(username, password);
        if (auth) {
            User user = userService.getUserByUsername(username);
            UserManager.getInstance().setCurrentUser(user);
            messageLabel.setForeground(new Color(0, 128, 0));
            messageLabel.setText("Login successful.");
            SwingUtilities.invokeLater(() -> new PosMain().setVisible(true));
            dispose();
        } else {
            messageLabel.setForeground(Color.RED);
            messageLabel.setText("Invalid credentials.");
        }
    }

    public static void main(String[] args) {
        try {
            lockSocket = new ServerSocket(9999);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Instance running");
            System.exit(1);
        }
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                lockSocket.close();
            } catch (IOException ignored) {
            }
        }));

        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
