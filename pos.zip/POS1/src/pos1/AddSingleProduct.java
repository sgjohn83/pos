package pos1;

import javax.swing.*;

public class AddSingleProduct extends JFrame {

    public JTextField invoiceNoField;
    public JComboBox<String> productNameCombo;
    public JComboBox<String> brandCombo;
    public JComboBox<String> categoryCombo;
    public JComboBox<String> unitCombo;
    public JTextField skuField;
    public JButton generateSkuButton;
    public JTextField barcodeField;
    public JComboBox<String> isTaxableCombo;
    public JTextField taxRateField;
    public JTextField unitPriceField;
    public JTextField quantityField;
    public JTextField discountField;
    public JTextField totalField;
    public JTextField hsnField;
    public JButton calcTotalButton;
    public JButton submitButton;

    public AddSingleProduct() {
        setTitle("Add Single Product");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        initComponents();
        pack();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        JLabel invoiceLabel = new JLabel("Invoice No");
        invoiceNoField = new JTextField();
        invoiceNoField.setEditable(false);

        JLabel productLabel = new JLabel("Product Name");
        productNameCombo = new JComboBox<>();

        JLabel brandLabel = new JLabel("Brand");
        brandCombo = new JComboBox<>();

        JLabel categoryLabel = new JLabel("Category");
        categoryCombo = new JComboBox<>();

        JLabel unitLabel = new JLabel("Unit");
        unitCombo = new JComboBox<>(new String[] {
            "Select Unit", "Piece", "Meter", "Set", "Foot", "Inch", "Roll", "Packet", "Box",
            "Bundle", "Length", "Pair", "Dozen", "Tube", "Can", "Bottle", "Litre", "Kg", "Gram",
            "Joint", "Valve", "Tap", "Fitting", "Connector", "Nut", "Bolt", "Clamp", "Washer",
            "Seal", "Cap", "Ring", "Plug", "Nipple", "Socket", "Elbow", "Reducer", "Flange", "Rod",
            "Bar", "Coil", "Strip", "Tape", "Tray", "Disc", "Brush", "Sheet", "Jar", "Millilitre"
        });

        JLabel skuLabel = new JLabel("SKU");
        skuField = new JTextField();
        skuField.setEditable(false);
        generateSkuButton = new JButton("Generate SKU");

        JLabel barcodeLabel = new JLabel("Barcode");
        barcodeField = new JTextField();

        JLabel hsnLabel = new JLabel("HSN Code");
        hsnField = new JTextField();

        JLabel isTaxableLabel = new JLabel("Is Taxable");
        isTaxableCombo = new JComboBox<>(new String[] { "Yes", "No" });

        JLabel taxRateLabel = new JLabel("Tax Rate");
        taxRateField = new JTextField("18");

        JLabel unitPriceLabel = new JLabel("Unit Price");
        unitPriceField = new JTextField();

        JLabel quantityLabel = new JLabel("Quantity");
        quantityField = new JTextField("1");

        JLabel discountLabel = new JLabel("Discount");
        discountField = new JTextField("0");

        JLabel totalLabel = new JLabel("Total");
        totalField = new JTextField();
        totalField.setEditable(false);
        calcTotalButton = new JButton("Calc Total");

        submitButton = new JButton("Submit");

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup()
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup()
                        .addComponent(invoiceLabel)
                        .addComponent(productLabel)
                        .addComponent(brandLabel)
                        .addComponent(categoryLabel)
                        .addComponent(unitLabel)
                        .addComponent(skuLabel)
                        .addComponent(barcodeLabel)
                        .addComponent(hsnLabel))
                    .addGroup(layout.createParallelGroup()
                        .addComponent(invoiceNoField)
                        .addComponent(productNameCombo)
                        .addComponent(brandCombo)
                        .addComponent(categoryCombo)
                        .addComponent(unitCombo)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(skuField, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(generateSkuButton))
                        .addComponent(barcodeField)
                        .addComponent(hsnField))
                    .addGroup(layout.createParallelGroup()
                        .addComponent(isTaxableLabel)
                        .addComponent(taxRateLabel)
                        .addComponent(unitPriceLabel)
                        .addComponent(quantityLabel)
                        .addComponent(discountLabel)
                        .addComponent(totalLabel))
                    .addGroup(layout.createParallelGroup()
                        .addComponent(isTaxableCombo)
                        .addComponent(taxRateField)
                        .addComponent(unitPriceField)
                        .addComponent(quantityField)
                        .addComponent(discountField)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(totalField, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(calcTotalButton))))
                .addComponent(submitButton, GroupLayout.Alignment.CENTER)
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(invoiceLabel).addComponent(invoiceNoField)
                    .addComponent(isTaxableLabel).addComponent(isTaxableCombo))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(productLabel).addComponent(productNameCombo)
                    .addComponent(taxRateLabel).addComponent(taxRateField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(brandLabel).addComponent(brandCombo)
                    .addComponent(unitPriceLabel).addComponent(unitPriceField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(categoryLabel).addComponent(categoryCombo)
                    .addComponent(quantityLabel).addComponent(quantityField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(unitLabel).addComponent(unitCombo)
                    .addComponent(discountLabel).addComponent(discountField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(skuLabel)
                    .addComponent(skuField)
                    .addComponent(generateSkuButton)
                    .addComponent(totalLabel)
                    .addComponent(totalField)
                    .addComponent(calcTotalButton))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(barcodeLabel).addComponent(barcodeField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(hsnLabel).addComponent(hsnField))
                .addComponent(submitButton)
        );
    }
}
