package pos1;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CalculationUtil {

    private static final BigDecimal TAX_RATE = new BigDecimal("0.18");
    private static final BigDecimal ONE_HUNDRED = new BigDecimal("100");

    public static BigDecimal calculateTotalAmount(BigDecimal unitPrice, BigDecimal quantity, BigDecimal discountPercentage) {
        // discountAmountPerUnit = unitPrice * (discount / 100)
        BigDecimal discountAmountPerUnit = unitPrice.multiply(discountPercentage).divide(ONE_HUNDRED, 4, RoundingMode.HALF_UP);

        // netUnitPrice = unitPrice - discountAmountPerUnit
        BigDecimal netUnitPrice = unitPrice.subtract(discountAmountPerUnit);

        // subtotal = netUnitPrice * quantity
        BigDecimal subtotal = netUnitPrice.multiply(quantity);

        // tax = subtotal * TAX_RATE
        BigDecimal tax = subtotal.multiply(TAX_RATE);

        // total = subtotal + tax
        return subtotal.add(tax).setScale(2, RoundingMode.HALF_UP);
    }
}
