package pos1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Base64;

public class TrialManager {
    private static final String FILE_NAME = "SystemCacheData.tmp";
    private static final String FILE_PATH = System.getProperty("user.home") + File.separator + FILE_NAME;
    private static final int TRIAL_DAYS = 15;

    public static boolean isTrialValid() {
        try {
            File file = new File(FILE_PATH);
            System.out.println("Trial file path: " + FILE_PATH);

            LocalDate today = LocalDate.now();

            if (!file.exists()) {
                writeEncodedData(file, today, today);
                setFileHiddenOnWindows(file);
                return true;
            }

            String encoded = readEncodedData(file);
            String decoded = new String(Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8);

            String[] parts = decoded.split(";");
            LocalDate startDate = null, lastCheckedDate = null;

            for (String part : parts) {
                if (part.startsWith("start=")) {
                    startDate = LocalDate.parse(part.substring(6));
                } else if (part.startsWith("last=")) {
                    lastCheckedDate = LocalDate.parse(part.substring(5));
                }
            }

            if (startDate == null || lastCheckedDate == null) {
                throw new IOException("Corrupted trial file");
            }

            // Detect rollback
            if (today.isBefore(lastCheckedDate)) {
                System.out.println("System clock rollback detected!");
                return false;
            }

            long daysUsed = ChronoUnit.DAYS.between(startDate, today);
            System.out.println("Trial days used: " + daysUsed + " / " + TRIAL_DAYS);

            if (daysUsed > TRIAL_DAYS) {
                return false;
            }

            // Update lastCheckedDate
            writeEncodedData(file, startDate, today);
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false; // On failure, block access
        }
    }

    private static void writeEncodedData(File file, LocalDate startDate, LocalDate lastCheckedDate) throws IOException {
        String content = "start=" + startDate + ";last=" + lastCheckedDate;
        String encoded = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
        try (BufferedWriter writer = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8)) {
            writer.write(encoded);
        }
    }

    private static String readEncodedData(File file) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
            return reader.readLine();
        }
    }

    private static void setFileHiddenOnWindows(File file) {
        try {
            if (System.getProperty("os.name").toLowerCase().contains("win")) {
                Process p = Runtime.getRuntime().exec("attrib +H \"" + file.getAbsolutePath() + "\"");
                p.waitFor();
            }
        } catch (Exception ignored) {}
    }

    // Optional: Dev-only reset method
    public static void resetTrial() {
        File file = new File(FILE_PATH);
        if (file.exists()) file.delete();
    }
}
