package pos1;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import com.toedter.calendar.JDateChooser;
import controller.SalesReportController;

public class SalesReportView extends JFrame {

    // Panels
    public JPanel filterPanel;
    public JPanel summaryPanel;

    // Filter components
    public JLabel searchLabel;
    public JTextField searchField;
    public JLabel fromLabel;
    public JDateChooser fromDateChooser;
    public JLabel toLabel;
    public JDateChooser toDateChooser;
    public JButton refreshButton;

    // Tables
    public JTable reportTable;
    public JScrollPane tableScrollPane;
    public JTable itemsTable;
    public JScrollPane itemsScrollPane;

    // Summary cards
    public JLabel totalTransactionsLabel;
    public JLabel totalSalesLabel;
    public JLabel totalCostLabel;
    public JLabel profitLabel;

    public SalesReportView() {
        super("Sales Report");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1200, 700);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        // ===== FILTER PANEL =====
        filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Filters"));

        searchLabel = new JLabel("Search:");
        searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(150, 25));
        fromLabel = new JLabel("From:");
        fromDateChooser = new JDateChooser();
        fromDateChooser.setPreferredSize(new Dimension(120, 25));
        toLabel = new JLabel("To:");
        toDateChooser = new JDateChooser();
        toDateChooser.setPreferredSize(new Dimension(120, 25));
        refreshButton = new JButton("Refresh");
        refreshButton.setPreferredSize(new Dimension(100, 30));
        refreshButton.addActionListener(e ->
            new SalesReportController(this).refreshReport()
        );

        filterPanel.add(searchLabel);
        filterPanel.add(searchField);
        filterPanel.add(fromLabel);
        filterPanel.add(fromDateChooser);
        filterPanel.add(toLabel);
        filterPanel.add(toDateChooser);
        filterPanel.add(refreshButton);

        // ===== REPORT TABLE =====
        DefaultTableModel reportModel = new DefaultTableModel(
            new Object[][] {},
            new String[]{
                "Sno", "Invoice No", "Date", "Customer", "Mobile",
                "Quantity", "Total Before Discount", "Total Discount",
                "Total Sales", "Tax Amount", "Cost", "Paid", "Profit", "Sold By"
            }
        ) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        reportTable = new JTable(reportModel);
        setupTableRenderers(reportTable);
        tableScrollPane = new JScrollPane(reportTable);

        // ===== ITEMS TABLE =====
        DefaultTableModel itemsModel = new DefaultTableModel(
            new Object[][] {},
            new String[]{ "Brand", "Name", "Category", "Quantity", "Total" }
        ) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        itemsTable = new JTable(itemsModel);
        setupItemTableRenderers(itemsTable);
        itemsScrollPane = new JScrollPane(itemsTable);

        // ===== SPLIT PANE =====
        JSplitPane split = new JSplitPane(
            JSplitPane.HORIZONTAL_SPLIT,
            tableScrollPane,
            itemsScrollPane
        );
        split.setDividerLocation(750);
        split.setResizeWeight(0.7);

        // ===== SUMMARY PANEL =====
        summaryPanel = new JPanel(new GridLayout(1, 4, 10, 0));
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        totalTransactionsLabel = createSummaryCard("Total Transactions", "0");
        totalSalesLabel        = createSummaryCard("Total Sales",        "0.00");
        totalCostLabel         = createSummaryCard("Total Cost",         "0.00");
        profitLabel            = createSummaryCard("Profit",             "0.00");
        summaryPanel.add(totalTransactionsLabel);
        summaryPanel.add(totalSalesLabel);
        summaryPanel.add(totalCostLabel);
        summaryPanel.add(profitLabel);

        // ===== MAIN LAYOUT =====
        setLayout(new BorderLayout(10, 10));
        add(filterPanel, BorderLayout.NORTH);
        add(split,       BorderLayout.CENTER);
        add(summaryPanel,BorderLayout.SOUTH);

        pack();
        computeSummary();
    }

    private void setupTableRenderers(JTable table) {
        for (int col = 0; col < table.getColumnCount(); col++) {
            int align = (col == 0 || (col >= 5 && col <= 12))
                        ? SwingConstants.RIGHT
                        : SwingConstants.LEFT;
            DefaultTableCellRenderer renderer = new NumericCellRenderer(align);
            table.getColumnModel().getColumn(col).setCellRenderer(renderer);
        }
    }

    private void setupItemTableRenderers(JTable table) {
        for (int col = 0; col < table.getColumnCount(); col++) {
            int align = (col >= 3 && col <= 4)
                        ? SwingConstants.RIGHT
                        : SwingConstants.LEFT;
            table.getColumnModel().getColumn(col)
                 .setCellRenderer(new NumericCellRenderer(align));
        }
    }

    private JLabel createSummaryCard(String title, String value) {
        JLabel lbl = new JLabel(String.format(
            "<html><div style='text-align:center;'><b>%s</b><br>" +
            "<span style='font-size:18px;'>%s</span></div></html>",
            title, value
        ), SwingConstants.CENTER);
        lbl.setOpaque(true);
        lbl.setBackground(new Color(245, 245, 245));
        lbl.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        return lbl;
    }

    public void computeSummary() {
        DefaultTableModel model = (DefaultTableModel) reportTable.getModel();
        int count = model.getRowCount();
        double totalSales = 0, totalCost = 0, totalProfit = 0;
        for (int i = 0; i < count; i++) {
            totalSales += Double.parseDouble(model.getValueAt(i, 8).toString());
            totalCost  += Double.parseDouble(model.getValueAt(i,10).toString());
            totalProfit+= Double.parseDouble(model.getValueAt(i,12).toString());
        }
        totalTransactionsLabel.setText(formatCard("Total Transactions", String.valueOf(count)));
        totalSalesLabel       .setText(formatCard("Total Sales",        String.format("%.2f", totalSales)));
        totalCostLabel        .setText(formatCard("Total Cost",         String.format("%.2f", totalCost)));
        profitLabel           .setText(formatCard("Profit",             String.format("%.2f", totalProfit)));
    }

    private String formatCard(String title, String val) {
        return String.format(
            "<html><div style='text-align:center;'><b>%s</b><br>" +
            "<span style='font-size:18px;'>%s</span></div></html>",
            title, val
        );
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SalesReportView().setVisible(true));
    }

    // Custom renderer for numeric cells with profit-based row coloring
    class NumericCellRenderer extends DefaultTableCellRenderer {
        private static final int PROFIT_COLUMN = 12;  // zero-based index of the Profit column
        private final int alignment;

        public NumericCellRenderer(int alignment) {
            this.alignment = alignment;
            setHorizontalAlignment(alignment);
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            Component c = super.getTableCellRendererComponent(
                table, value, isSelected, hasFocus, row, column
            );

            if (isSelected) {
                return c;
            }

            Color bg = table.getBackground();
            try {
                Object profitObj = table.getValueAt(row, PROFIT_COLUMN);
                if (profitObj != null) {
                    double profit = Double.parseDouble(profitObj.toString());
                    if (profit > 0) {
                        bg = new Color(198, 239, 206); // light green
                    } else if (profit < 0) {
                        bg = new Color(255, 199, 206); // light red
                    }
                }
            } catch (Exception ignored) {}

            c.setBackground(bg);
            return c;
        }
    }
}
