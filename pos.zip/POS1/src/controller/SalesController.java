/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import model.Customer;
import pos1.DBConnection;
import pos1.PosMain;
import pos1.ReportPrinter;
import service.CustomerService;
import service.InventoryBatchService;
import service.UserService;

/**
 *
 * @author sgjohn
 */
public class SalesController {

    private PosMain view;

    public SalesController(PosMain view) {
        this.view = view;
        saveSales();
    }

    private void saveSales() {
        String invoice_no = view.salesBillNoTxt.getText();
        String invoice_date = view.salesDateTxt.getText();
        Date date;

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy HH:mm");
            date = formatter.parse(invoice_date);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Invalid date format.");
            return;
        }

        String username = view.salesuserTxt.getText();
        String cname = view.customerNameTxt.getText();
        String cmobile = view.customerMobileTxt.getText();
        JTable salesTbl = view.salesTable;
        double cgst = Double.parseDouble(view.cgstTxt.getText());
        double sgst = Double.parseDouble(view.sgstTxt.getText());
        double gtotal = Double.parseDouble(view.gTotalTxt.getText());
        double stotal = Double.parseDouble(view.subTotalTxt.getText());
        int cust_id = storeCustomer(cname, cmobile);
        int uid = new UserService().getUserByUsername(username).getId();

        String insertSalesQuery = "INSERT INTO sales (customer_id, invoice_number, sale_date, total_amount, discount, tax, net_amount, created_by) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        String insertItemQuery = "INSERT INTO sale_items (sale_id, product_id, quantity, price, tax_rate,discount,cogs) VALUES (?, ?, ?, ?, ?,?,?)";
        String updateStockQuery = "UPDATE stock SET quantity = quantity - ? WHERE product_id = ?";
        String selectStockQuery = "SELECT quantity FROM stock WHERE product_id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            // 1. Check stock availability BEFORE any inserts
            try (PreparedStatement pstCheckStock = conn.prepareStatement(selectStockQuery)) {
                for (int row = 0; row < salesTbl.getRowCount(); row++) {
                    int productId = Integer.parseInt(salesTbl.getValueAt(row, 0).toString());
                    double quantity = Double.parseDouble(salesTbl.getValueAt(row, 6).toString());

                    pstCheckStock.setInt(1, productId);
                    try (ResultSet rs = pstCheckStock.executeQuery()) {
                        if (rs.next()) {
                            double availableQty = rs.getDouble("quantity");
                            if (availableQty < quantity) {
                                String productName = salesTbl.getValueAt(row, 2).toString(); // Column 2 = Name
                                JOptionPane.showMessageDialog(view,
                                        "Insufficient stock for product: " + productName
                                        + "\nAvailable: " + availableQty + ", Required: " + quantity,
                                        "Stock Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        } else {
                            JOptionPane.showMessageDialog(view,
                                    "Stock record not found for product ID: " + productId,
                                    "Stock Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    }
                }
            }

            // 2. All stocks are available — proceed with inserts
            int sale_id;
            try (PreparedStatement pst = conn.prepareStatement(insertSalesQuery, Statement.RETURN_GENERATED_KEYS)) {
                pst.setInt(1, cust_id);
                pst.setString(2, invoice_no);
                pst.setDate(3, new java.sql.Date(date.getTime()));
                pst.setDouble(4, gtotal);
                pst.setDouble(5, 0.00); // discount
                pst.setDouble(6, cgst + sgst); // tax
                pst.setDouble(7, gtotal); // net_amount
                pst.setInt(8, uid);
                pst.executeUpdate();

                try (ResultSet rs = pst.getGeneratedKeys()) {
                    if (rs.next()) {
                        sale_id = rs.getInt(1);
                    } else {
                        conn.rollback();
                        JOptionPane.showMessageDialog(view, "Failed to retrieve generated sale ID.");
                        return;
                    }
                }
            }

            // 3. Insert sale items and update stock
            try (PreparedStatement pstItem = conn.prepareStatement(insertItemQuery);
                    PreparedStatement pstStock = conn.prepareStatement(updateStockQuery)) {

                for (int row = 0; row < salesTbl.getRowCount(); row++) {
                    int productId = Integer.parseInt(salesTbl.getValueAt(row, 0).toString());
                    double price = Double.parseDouble(salesTbl.getValueAt(row, 5).toString());
                    double quantity = Double.parseDouble(salesTbl.getValueAt(row, 6).toString());
                    double discount = Double.parseDouble(salesTbl.getValueAt(row, 7).toString());
                    double taxRate = 0.00;

                    ///////   inventory batch /////////////////////
                    InventoryBatchService ivSer = new InventoryBatchService(DBConnection.getConnection());
                    InventoryBatchService.FifoResult p = ivSer.getFifoCostAndUpdateStock(productId, new BigDecimal(quantity), true);
                    BigDecimal totalcogs = p.totalCogs;
                    BigDecimal discountPercent = p.totalDiscount;
                    BigDecimal discountAmount = totalcogs.multiply(discountPercent)
                            .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

                    // Apply discount
                    BigDecimal discountedPrice = totalcogs.subtract(discountAmount);

                    // Calculate tax amount
                    BigDecimal taxAmount = discountedPrice.multiply(new BigDecimal(18))
                            .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

                    // Final price after discount and tax
                    BigDecimal cogs = discountedPrice.add(taxAmount);

                    //////////////////////////////////////////
                    // Insert sale item
                    pstItem.setInt(1, sale_id);
                    pstItem.setInt(2, productId);
                    pstItem.setDouble(3, quantity);
                    pstItem.setDouble(4, price);
                    pstItem.setDouble(5, taxRate);
                    pstItem.setDouble(6, discount);
                    pstItem.setDouble(7, cogs.doubleValue());
                    pstItem.addBatch();

                    // Update stock
                    pstStock.setDouble(1, quantity);
                    pstStock.setInt(2, productId);
                    pstStock.addBatch();

                }

                pstItem.executeBatch();
                pstStock.executeBatch();

            }

            conn.commit();

            JOptionPane.showMessageDialog(view, "Sale saved successfully.");
            printBill(invoice_no);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(view, "Database error: " + e.getMessage());
        }
    }

    private int storeCustomer(String cname, String cmobile) {
        CustomerService cs = new CustomerService();
        Customer c = new Customer();
        c.setName(cname);
        c.setPhone(cmobile);
        c.setCreatedAt(new java.sql.Timestamp(new Date().getTime()));

        Customer addOrGetCustomer = cs.addOrGetCustomer(c);
        return addOrGetCustomer.getId();
    }

    private void printBill(String invoiceno) {
        Map<String, Object> params = new HashMap<>();
        params.put("BILLNO", invoiceno);

        ReportPrinter.printReport("print.jasper", params);
    }

}
