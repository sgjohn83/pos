package controller;

import model.SalesGSTReportItem;
import service.SalesGSTReportService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import pos1.SalesGstReportView;

public class SalesGstReportController {
    private final SalesGstReportView view;

    public SalesGstReportController(SalesGstReportView view) {
        this.view = view;
        view.btnGenerate.addActionListener(e -> onGenerate());
    }

    private void onGenerate() {
        Date fromDate = view.fromDateChooser.getDate();
        Date toDate = view.toDateChooser.getDate();

        LocalDate from = null;
        LocalDate to = null;

        // Allow empty dates: if a chooser is empty, treat as unbounded
        if (fromDate != null) {
            from = fromDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        }
        if (toDate != null) {
            to = toDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        }

        try {
            SalesGSTReportService service = new SalesGSTReportService();
            // Service should handle nulls as unbounded range
            List<SalesGSTReportItem> items = service.getReportItems(from, to);

            DefaultTableModel model = (DefaultTableModel) view.table.getModel();
            model.setRowCount(0);

            BigDecimal totalTaxable = BigDecimal.ZERO;
            BigDecimal totalCgst = BigDecimal.ZERO;
            BigDecimal totalSgst = BigDecimal.ZERO;
            BigDecimal totalTax = BigDecimal.ZERO;
            BigDecimal grandTotal = BigDecimal.ZERO;

            for (SalesGSTReportItem item : items) {
                BigDecimal quantity = safeBigDecimal(item.getQuantity());
                BigDecimal netUnitPrice = safeBigDecimal(item.getNetUnitPrice());
                BigDecimal discountPercent = safeBigDecimal(item.getDiscountPercent());
                BigDecimal discountAmount = safeBigDecimal(item.getDiscountAmount());
                BigDecimal taxableValue = safeBigDecimal(item.getTaxableValue());
                BigDecimal totalTaxItem = safeBigDecimal(item.getTotalTax());
                BigDecimal cgst = safeBigDecimal(item.getCgst());
                BigDecimal sgst = safeBigDecimal(item.getSgst());
                BigDecimal grossUnitPrice = safeBigDecimal(item.getGrossUnitPrice());

                model.addRow(new Object[]{
                    item.getInvoiceNumber(),
                    item.getSaleDate(),
                    item.getProductName(),
                    quantity,
                    netUnitPrice,
                    discountPercent,
                    discountAmount,
                    taxableValue,
                    totalTaxItem,
                    cgst,
                    sgst,
                    grossUnitPrice
                });

                totalTaxable = totalTaxable.add(taxableValue);
                totalCgst = totalCgst.add(cgst);
                totalSgst = totalSgst.add(sgst);
                totalTax = totalTax.add(totalTaxItem);
                grandTotal = grandTotal.add(grossUnitPrice.multiply(quantity));
            }

            view.lblTotalTaxableValue.setText("Total Taxable:  " +formatCurrency(totalTaxable));
            view.lblTotalCgst.setText("Total CGST: " +formatCurrency(totalCgst));
            view.lblTotalSgst.setText("Total SGST: " +formatCurrency(totalSgst));
            view.lblTotalTax.setText("Total Tax: " +formatCurrency(totalTax));
            view.lblTotalInvoiceValue.setText("Grand Total: " +formatCurrency(grandTotal));
            
            
          

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(view, "Error generating report: " + ex.getMessage());
        }
    }

    // Helper method to handle null BigDecimal values
    private BigDecimal safeBigDecimal(BigDecimal value) {
        return value != null ? value : BigDecimal.ZERO;
    }

    // Helper method to format currency values
    private String formatCurrency(BigDecimal value) {
        return String.format("%,.2f", value);
    }
}
