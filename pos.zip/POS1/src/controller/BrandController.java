/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import model.Brand;
import pos1.DBConnection;
import service.BrandService;

/**
 *
 * @author sgjohn
 */
public class BrandController {

    private Connection conn;

  public void addBrand(String text) {
        conn = DBConnection.getConnection();
        Brand b = new Brand();
        b.setName(text);
        BrandService bs = new BrandService(conn);
        try {
            boolean addBrand = bs.addBrand(b);
            if (addBrand) {
                JOptionPane.showMessageDialog(null, "Brand added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add brand.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            Logger.getLogger(BrandController.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

   

    public void loadBrands(JComboBox<String> brandCombo) {
        conn = DBConnection.getConnection();
        BrandService bs = new BrandService(conn);
        try {
            List<Brand> allBrands = bs.getAllBrands();
            // Clear existing items
        brandCombo.removeAllItems();

        // Optional: Add a prompt item
     

        // Add brand names
        for (Brand brand : allBrands) {
            brandCombo.addItem(brand.getName()); // Assuming Brand has getName()
        }


        } catch (SQLException ex) {
            Logger.getLogger(BrandController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
