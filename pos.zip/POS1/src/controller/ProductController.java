/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import model.Product;
import pos1.DBConnection;
import service.BrandService;
import service.ProductService;

/**
 *
 * @author sgjohn
 */
public class ProductController {

    private Connection conn;

    public void loadProducts(JComboBox<String> productNameCombo) {
        conn = DBConnection.getConnection();
        ProductService ps = new ProductService(conn);
        try {
            List<Product> allProducts = ps.getAllProducts();
            // Clear existing items
            productNameCombo.removeAllItems();
            productNameCombo.addItem("");
            // Optional: Add a prompt
            // Add all product names
            for (Product product : allProducts) {
                productNameCombo.addItem(product.getName()); // Assuming Product has getName()
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void updateProductsByBrand(String bname, JComboBox<String> productNameCombo) {
        BrandService bs = new BrandService(DBConnection.getConnection());
        if (bname == null || bname.isEmpty()) {
        return; // or return -1, or throw exception based on your use case
    }
        Integer brandId = bs.getBrandIdByName(bname);
        ProductService ps = new ProductService(DBConnection.getConnection());
        List<Product> productsByBrandId = ps.getProductsByBrandId(brandId);
        // Clear and repopulate the combo box
        productNameCombo.removeAllItems();
        for (Product p : productsByBrandId) {
            productNameCombo.addItem(p.getName());
        }
    }

}
