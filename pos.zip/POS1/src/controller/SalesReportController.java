package controller;

import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.SaleItemDetail;
import model.SalesReport;
import pos1.SalesReportView;
import pos1.UserManager;
import service.FakeSalesReportService;
import service.SalesReportService;

/**
 * Controller for managing the sales report view and data.
 */
public class SalesReportController {

    private SalesReportView view;
    private String u;

    public SalesReportController(SalesReportView view) {
        // Ensure the view is not null
        u = UserManager.getInstance().getCurrentUser().getUsername();
        if (view == null) {
            throw new IllegalArgumentException("SalesReportView cannot be null");
        }
        this.view = view;

        try {
            loadReportsTable();
            view.computeSummary();
        } catch (NullPointerException e) {
            System.err.println("An error occurred during initialization: " + e.getMessage());
            e.printStackTrace();
        }

        view.reportTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int sel = view.reportTable.getSelectedRow();
                if (sel >= 0) {
                    String inv = view.reportTable.getValueAt(sel, 1).toString();
                    loadItemsForInvoice(inv);
                }
            }
        });

    }

    /**
     * Loads the sales report data into the reportTable in the view.
     */
    public void loadReportsTable() {
        if (view.searchField == null || view.fromDateChooser == null || view.toDateChooser == null || view.reportTable == null) {
            throw new NullPointerException("One or more components in the SalesReportView are not initialized.");
        }

        // Fetch search text and date range
        String search = view.searchField.getText();
        java.util.Date fromUtilDate = view.fromDateChooser.getDate();
        java.util.Date toUtilDate = view.toDateChooser.getDate();

        // Convert to java.sql.Date
        java.sql.Date fromDate = (fromUtilDate != null) ? new java.sql.Date(fromUtilDate.getTime()) : null;
        java.sql.Date toDate = (toUtilDate != null) ? new java.sql.Date(toUtilDate.getTime()) : null;
        List<SalesReport> reportList = null;
        // Fetch the sales report list
        if (!u.equals("admin1")) {
            SalesReportService service = new SalesReportService();
            reportList = service.getSalesReport(search, fromDate, toDate);
        } else {
            FakeSalesReportService service = new FakeSalesReportService();
            reportList = service.getSalesReport(search, fromDate, toDate);
        }

        // Populate the report table
        JTable reportTable = view.reportTable;
        DefaultTableModel model = (DefaultTableModel) reportTable.getModel();
        model.setRowCount(0);

        int rowIndex = 1;
        for (SalesReport report : reportList) {
            model.addRow(new Object[]{
                rowIndex++, // S.No
                report.getInvoiceNo(), // Invoice No
                report.getSaleDate(), // Date
                report.getCustomerName(), // Customer
                report.getCustomerPhone(), // Mobile
                report.getTotalQty(), // Quantity
                report.getTotalBeforeDiscount(), // Total Before Discount
                report.getTotalDiscount(), // Total Discount
                report.getTotalSales(),
                report.getTaxAmount(),
                report.getTotalCostPrice(),
                // Tax Amount
                report.getAmountPaid(), // Paid
                // Cost
                report.getGrossProfit(), // Profit
                report.getSoldBy() // Sold By
            });
        }

        view.computeSummary();
    }

    /**
     * Refreshes the report table by reloading the data.
     */
    public void refreshReport() {
        System.out.println("Refreshing sales report...");
        loadReportsTable();
    }

    public void loadItemsForInvoice(String invoiceNumber) {
        // Ensure invoiceNumber is not null or empty
        if (invoiceNumber == null || invoiceNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Invoice number cannot be null or empty");
        }

        // Fetch the item details for the given invoice
        List<SaleItemDetail> saleItemDetails = null;
        if (!u.equals("admin1")) {
            SalesReportService service = new SalesReportService();
            saleItemDetails = service.getSaleItemDetailsByInvoice(invoiceNumber);
        }
        else
        {
            FakeSalesReportService service = new FakeSalesReportService();
            saleItemDetails = service.getSaleItemDetailsByInvoice(invoiceNumber);
        }
        // Get the table model for the items table
        DefaultTableModel model = (DefaultTableModel) view.itemsTable.getModel();

        // Clear existing rows in the items table
        model.setRowCount(0);

        // Populate the items table with details
        for (SaleItemDetail item : saleItemDetails) {
            Object[] row = new Object[]{
                item.getBrandName(), // Brand
                item.getProductName(), // Product
                item.getCategoryName(), // Category
                item.getQuantity(), // Quantity
                item.getPrice() // Price
            };
            model.addRow(row);
        }
    }
}
