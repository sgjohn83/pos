/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.InventoryBatch;
import model.Product;
import model.ProductSummary;
import model.Supplier;
import model.User;
import pos1.DBConnection;
import pos1.PosMain;
import service.BrandService;
import service.CategoryService;
import service.InventoryBatchService;
import service.SupplierService;
import service.UserService;

/**
 *
 * @author sgjohn
 */
public class PurchaseController {

    private PosMain view;

    public PurchaseController(PosMain view) {
        this.view = view;
        saveToDb();
    }

    private void saveToDb() {
        //get bill details 
        String invoiceno = view.invoicenoTxt.getText();
        String username = view.userTxt.getText();
        Date date = view.jDateChooser1.getDate();

        UserService us = new UserService();
        User users = us.getUserByUsername(username);
        //check supplier is there or not
        SupplierService ss = new SupplierService();
        Supplier supplier = ss.getSupplierByName((String) view.supplierCombo.getSelectedItem());
        if (view.supplierCombo.getSelectedItem().equals("Select Supplier")) {
            JOptionPane.showMessageDialog(null, "Please select a valid supplier.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (supplier == null) {
            Supplier s = new Supplier();
            s.setName((String) view.supplierCombo.getSelectedItem());
            s.setPhone(view.supplierPhoneTxt.getText());
            s.setAddress(view.supplierAddrTxt.getText());
            s.setEmail("");
            s.setCreatedAt(new java.sql.Timestamp(new java.util.Date().getTime()));
            supplier = ss.insert(s);

        }

        List<ProductSummary> productSummaries = getProductSummariesFromTable(view.summaryTable);
        List<Product> products = new ArrayList<>();
        CategoryService cs = new CategoryService(DBConnection.getConnection());
        BrandService bs = new BrandService(DBConnection.getConnection());
        Connection conn = DBConnection.getConnection();
        PreparedStatement psInsertProduct = null;
        try {
            conn.setAutoCommit(false);  // Start transaction
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseController.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Prepare SQL query for inserting products
        String sql = "INSERT INTO product (sku, barcode, name,hsn_code, category_id, brand_id, unit, price, is_taxable, tax_rate, status, created_at) "
                + "VALUES (?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            psInsertProduct = conn.prepareStatement(sql);

            for (ProductSummary summary : productSummaries) {
                Product product = new Product();

                product.setSku(summary.getSku());
                product.setBarcode(summary.getBarcode());
                product.setName(summary.getProductName());
                product.setHsnCode(summary.getHsnCode());
                // These should be mapped based on combo box data or service (mocked here)
                Integer categoryId = cs.getCategoryIdByName(summary.getCategoryName());
                Integer brandId = bs.getBrandIdByName(summary.getBrandName());
                product.setCategoryId(categoryId); // You can map category name to ID if needed
                product.setBrandId(brandId);    // You can map brand name to ID if needed

                product.setUnit(summary.getUnit());
                product.setPrice(new BigDecimal(summary.getPrice()));
                product.setIsTaxable(summary.getIsTaxable());
                product.setTaxRate(new BigDecimal(summary.getTaxRate()));
                product.setStatus("AVAILABLE");
                product.setCreatedAt(new Timestamp(System.currentTimeMillis()));

                products.add(product);

                int brand_id = product.getBrandId();
                int catid = product.getCategoryId();
                String pname = product.getName();
                PreparedStatement checkStmt = conn.prepareStatement(
                        "SELECT id FROM product WHERE brand_id = ? AND category_id = ? AND name = ?"
                );
                checkStmt.setInt(1, brand_id);
                checkStmt.setInt(2, catid);
                checkStmt.setString(3, pname);

                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Product already exists, skipping: " + pname);
                    continue; // inside a loop
                }

                // Set parameters in the prepared statement for batch insertion
                psInsertProduct.setString(1, product.getSku());
                String barcode = product.getBarcode();

                // Check if the barcode is empty (or null)
                if (barcode == null || barcode.isEmpty()) {
                    psInsertProduct.setNull(2, java.sql.Types.VARCHAR);  // Insert NULL into the second parameter
                } else {
                    psInsertProduct.setString(2, barcode);  // Insert the actual barcode value
                }
                if (product.getHsnCode() == null || product.getHsnCode().trim().isEmpty()) {
                    psInsertProduct.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    psInsertProduct.setString(4, product.getHsnCode().trim());
                }

                psInsertProduct.setString(3, product.getName());

                psInsertProduct.setInt(5, product.getCategoryId());
                psInsertProduct.setInt(6, product.getBrandId());
                psInsertProduct.setString(7, product.getUnit());
                psInsertProduct.setBigDecimal(8, product.getPrice());
                psInsertProduct.setString(9, product.getIsTaxable());
                psInsertProduct.setBigDecimal(10, product.getTaxRate());
                psInsertProduct.setString(11, product.getStatus());
                psInsertProduct.setTimestamp(12, product.getCreatedAt());

                // Add to batch
                psInsertProduct.addBatch();

            }
            // Execute the batch insert
            int[] result = psInsertProduct.executeBatch();

            // If everything went well, commit the transaction
            conn.commit();

            // You can process the results here if needed (e.g., checking insert counts)
            System.out.println("Inserted products: " + result.length);
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            // Close resources
            try {
                if (psInsertProduct != null) {
                    psInsertProduct.close();
                }
                if (conn != null) {
                    conn.setAutoCommit(true);  // Reset auto-commit mode
                    conn.close();
                }
            } catch (SQLException closeEx) {
                closeEx.printStackTrace();
            }

        }
        insertPurchase(supplier.getId(), invoiceno, date, productSummaries, users.getId());
        DefaultTableModel model = (DefaultTableModel) view.summaryTable.getModel();
        model.setRowCount(0);
        resetPurchaseForm();
    }

    public List<ProductSummary> getProductSummariesFromTable(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        List<ProductSummary> productList = new ArrayList<>();

        for (int i = 0; i < model.getRowCount(); i++) {
            try {
                ProductSummary ps = new ProductSummary(
                        model.getValueAt(i, 0).toString(), // brandName
                        model.getValueAt(i, 1).toString(), // categoryName
                        model.getValueAt(i, 2).toString(), // productName
                        model.getValueAt(i, 4).toString(), // unit
                        model.getValueAt(i, 5).toString(), // sku
                        model.getValueAt(i, 6).toString(), // barcode
                        model.getValueAt(i, 7).toString(), // isTaxable
                        model.getValueAt(i, 8).toString(), // taxRate
                        Double.parseDouble(model.getValueAt(i, 9).toString()), // price
                        Integer.parseInt(model.getValueAt(i, 10).toString()), // quantity
                        Double.parseDouble(model.getValueAt(i, 11).toString()), // discount
                        Double.parseDouble(model.getValueAt(i, 11).toString()), // total\
                        model.getValueAt(i, 3).toString() // hsn
                );

                productList.add(ps);

            } catch (Exception e) {
                System.err.println("Error parsing row " + i + ": " + e.getMessage());
            }
        }

        return productList;
    }

    private void insertPurchase(int supplier_id, String invoiceno, Date date, List<ProductSummary> productSummaries, int user_id1) {
        Connection conn = null;
        PreparedStatement psInsertPurchase = null;
        PreparedStatement psInsertItem = null;
        PreparedStatement psUpdateStock = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // Begin transaction

            BigDecimal totalAmount = BigDecimal.ZERO;

            for (ProductSummary ps : productSummaries) {
                try {
                    BigDecimal price = BigDecimal.valueOf(ps.getPrice());
                    BigDecimal quantity = new BigDecimal(String.valueOf(ps.getQuantity())); // if quantity is int
                    BigDecimal discountPercent = BigDecimal.valueOf(ps.getDiscount());
                    BigDecimal taxRate = BigDecimal.ZERO;

                    if (ps.getTaxRate() != null && ps.getTaxRate().trim().length() > 0) {
                        taxRate = new BigDecimal(ps.getTaxRate().trim());
                    }

                    System.out.println("Processing product: " + ps.getProductName());
                    System.out.println("Price: " + price + ", Quantity: " + quantity + ", Discount%: " + discountPercent + ", TaxRate: " + taxRate);

                    // Total before discount
                    BigDecimal totalBeforeDiscount = price.multiply(quantity);
                    System.out.println("Total before discount: " + totalBeforeDiscount);

                    // Apply discount
                    BigDecimal discountAmount = totalBeforeDiscount.multiply(discountPercent)
                            .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
                    System.out.println("Discount amount: " + discountAmount);

                    BigDecimal totalAfterDiscount = totalBeforeDiscount.subtract(discountAmount);
                    System.out.println("Total after discount: " + totalAfterDiscount);

                    // Apply tax if applicable
                    BigDecimal finalTotal = totalAfterDiscount;
                    if (taxRate.compareTo(BigDecimal.ZERO) > 0) {
                        BigDecimal taxAmount = totalAfterDiscount.multiply(taxRate)
                                .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
                        finalTotal = totalAfterDiscount.add(taxAmount);
                        System.out.println("Tax amount: " + taxAmount);
                    }

                    System.out.println("Final total for product: " + finalTotal);

                    // Accumulate final total
                    totalAmount = totalAmount.add(finalTotal);
                    System.out.println("Running total amount: " + totalAmount);

                } catch (NumberFormatException e) {
                    System.err.println("Invalid number format in product: " + ps.getProductName());
                    continue;
                }
            }

            System.out.println("Grand Total: " + totalAmount);

// Format and display the total (if needed)
// totalTxt.setText(totalAmount.setScale(2, RoundingMode.HALF_UP).toString());
            // 2. Insert into purchases table
            String sqlPurchase = "INSERT INTO purchases (supplier_id, invoice_number, purchase_date, total_amount, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)";
            psInsertPurchase = conn.prepareStatement(sqlPurchase, Statement.RETURN_GENERATED_KEYS);
            psInsertPurchase.setInt(1, supplier_id);
            psInsertPurchase.setString(2, invoiceno);
            psInsertPurchase.setDate(3, new java.sql.Date(date.getTime()));
            psInsertPurchase.setBigDecimal(4, totalAmount);
            psInsertPurchase.setInt(5, user_id1);
            psInsertPurchase.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
            psInsertPurchase.executeUpdate();

            rs = psInsertPurchase.getGeneratedKeys();
            int purchaseId = 0;
            if (rs.next()) {
                purchaseId = rs.getInt(1);
            } else {
                throw new SQLException("Failed to retrieve purchase ID.");
            }

            // 3. Prepare statements for item insert and stock update
            String sqlItem = "INSERT INTO purchase_items (purchase_id, product_id, quantity, cost_price,discount) VALUES (?, ?, ?, ?,?)";
            String sqlStock = "INSERT INTO stock (product_id,"
                    + " quantity) VALUES (?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)";
            psInsertItem = conn.prepareStatement(sqlItem);
            psUpdateStock = conn.prepareStatement(sqlStock);

            List<InventoryBatch> inventoryBatchList = new ArrayList<>();
            InventoryBatchService ibvservice = new InventoryBatchService(DBConnection.getConnection());
            for (ProductSummary ps : productSummaries) {
                int productId = getProductIdBySku(ps.getSku(), conn);
                if (productId == 0) {
                    throw new SQLException("Product not found: " + ps.getSku());
                }

                BigDecimal quantity = new BigDecimal(ps.getQuantity());
                BigDecimal costPrice = new BigDecimal(ps.getPrice());
                BigDecimal discount = new BigDecimal(ps.getDiscount());

                //create inventory batch object
                // Insert into purchase_items
                psInsertItem.setInt(1, purchaseId);
                psInsertItem.setInt(2, productId);
                psInsertItem.setBigDecimal(3, quantity);
                psInsertItem.setBigDecimal(4, costPrice);
                psInsertItem.setBigDecimal(5, discount);
                psInsertItem.addBatch();

                // Update stock
                psUpdateStock.setInt(1, productId);
                psUpdateStock.setBigDecimal(2, quantity);
                psUpdateStock.addBatch();

                InventoryBatch ivb = new InventoryBatch();
                System.out.print("pid" + productId);
                ivb.setProductId(productId);
                ivb.setPurchaseId(purchaseId);
                ivb.setQuantity(quantity);
                ivb.setCostPrice(costPrice);
                ivb.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                ivb.setDiscount(discount);
                inventoryBatchList.add(ivb);

            }

            psInsertItem.executeBatch();
            psUpdateStock.executeBatch();

            conn.commit(); // Commit if everything succeeded
            ibvservice.addInventoryBatches(inventoryBatchList, DBConnection.getConnection()); // add inventory batch   

            JOptionPane.showMessageDialog(null, "Purchase transaction completed successfully.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            try {
                if (conn != null) {
                    conn.rollback(); // Rollback on error
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (psInsertPurchase != null) {
                    psInsertPurchase.close();
                }
                if (psInsertItem != null) {
                    psInsertItem.close();
                }
                if (psUpdateStock != null) {
                    psUpdateStock.close();
                }
                if (conn != null) {
                    conn.setAutoCommit(true);
                }
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

// Helper to get product ID from SKU
    private int getProductIdBySku(String sku, Connection conn) throws SQLException {
        String sql = "SELECT id FROM product WHERE sku = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, sku);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return 0;
    }

    private void resetPurchaseForm() {
        view.skuTxt.setText("");
        view.barcodeTxt.setText("");
        view.priceTxt.setText("");
        view.quantityTxt.setText("");
        view.totalTxt.setText("");
        view.totalQuantityLbl.setText("0");
        view.totalAmountLbl.setText("0.00");
        view.invoicenoTxt.setText("");
        view.jDateChooser1.setDate(null);
        view.supplierCombo.setSelectedItem("");
        view.supplierPhoneTxt.setText("");
        view.supplierAddrTxt.setText("");
        view.productNameCombo.setSelectedItem("");
    }

}
