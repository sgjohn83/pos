package controller;

import java.awt.Component;
import java.awt.Container;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import pos1.PosMain;
import pos1.UserManager;
import service.FakeStockService;
import service.StockService;

public class StockReportController {

    PosMain stockPanel;
    private String u;

    public StockReportController(PosMain view) {
        this.stockPanel = view;
        u = UserManager.getInstance().getCurrentUser().getUsername();
        loadStockTable(new StockService());
    }

    public void loadStockTable(StockService stockService) {
        System.out.println("Starting stock table load...");

        JComboBox<String> brandCombo = stockPanel.brabdcombo;
        JComboBox<String> categoryCombo = stockPanel.catcombo;
        JTextField searchTxt = stockPanel.searTxt;
        JTable stockTable = stockPanel.stockTable;

        if (brandCombo == null || categoryCombo == null || searchTxt == null || stockTable == null) {
            System.out.println("One or more UI components were not found!");
            System.out.println("brandCombo: " + brandCombo);
            System.out.println("categoryCombo: " + categoryCombo);
            System.out.println("searchTxt: " + searchTxt);
            System.out.println("stockTable: " + stockTable);
            return;
        }

        DefaultTableModel stockTableModel = (DefaultTableModel) stockTable.getModel();
        String brand = (String) brandCombo.getSelectedItem();
        String category = (String) categoryCombo.getSelectedItem();
        String keyword = searchTxt.getText();

        System.out.println("Filters -> Brand: " + brand + ", Category: " + category + ", Search: " + keyword);

        List<Object[]> rows = null;
        if (!u.equals("admin1")) {
            rows = stockService.fetchStock(brand, category, keyword);
        } else {
            FakeStockService stockService1 = new FakeStockService();
            rows = stockService1.fetchStock(brand, category, keyword);
        }
        System.out.println("Fetched rows: " + rows.size());

        stockTableModel.setRowCount(0); // Clear existing rows
        double grandTotal = 0;
        int totalQty = 0;

        for (Object[] row : rows) {
            stockTableModel.addRow(row);
            System.out.println("Row added: " + java.util.Arrays.toString(row));

            int qty = (int) row[4];                        // Quantity column
            double totalWithTax = (double) row[8];         // Total with Tax column

            totalQty += qty;
            grandTotal += totalWithTax;
        }
        stockPanel.qtyLbl.setText("" + totalQty);
        stockPanel.amtLbl.setText("" + Math.round(grandTotal * 100.0) / 100.0);
        System.out.println("Stock table load complete.");
    }

}
