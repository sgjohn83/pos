/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import model.Supplier;
import service.SupplierService;

/**
 *
 * @author sgjohn
 */
public class SupplierController {

    public void loadSuppliers(JComboBox<String> supplierCombo) {
        SupplierService ss = new SupplierService();
        try {
            List<Supplier> allSuppliers = ss.getAllSuppliers();
            supplierCombo.removeAllItems();

        // Add a default prompt item
       supplierCombo.addItem("");

        // Add each supplier's name to the combo box
        for (Supplier supplier : allSuppliers) {
            supplierCombo.addItem(supplier.getName());
        }
        } catch (SQLException ex) {
            Logger.getLogger(SupplierController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Supplier getSupplierDetails(String selectedItem) {
        SupplierService ss = new SupplierService();
        Supplier supplierByName = ss.getSupplierByName(selectedItem);
        return supplierByName;
    }
    
    
    
}
