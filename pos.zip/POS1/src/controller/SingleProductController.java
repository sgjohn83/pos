/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.InventoryBatch;
import model.Product;
import model.PurchaseItem;
import pos1.AddSingleProduct;
import pos1.CalculationUtil;
import pos1.DBConnection;
import pos1.PosMain;
import pos1.PurchaseReport;
import pos1.SKUGenerator;
import service.BrandService;
import service.CategoryService;
import service.InventoryBatchService;
import service.ProductService;
import service.PurchaseItemService;
import service.PurchaseService;
import service.StockService;

/**
 *
 * @author sgjohn
 */
public class SingleProductController {

    AddSingleProduct view;
    String invoice_no;
    PurchaseReportController pc;

    SingleProductController(String invoice_no, AddSingleProduct view, PurchaseReportController pc) {
        this.view = view;
        this.invoice_no = invoice_no;
        this.pc = pc;
        initilaize();
        view.submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {
                    SaveDetails();
                } catch (SQLException ex) {
                    Logger.getLogger(SingleProductController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
    }

    private void initilaize() {
        view.invoiceNoField.setText(invoice_no);
        new BrandController().loadBrands(view.brandCombo);
        new ProductController().loadProducts(view.productNameCombo);
        new CategoryController().loadCategories(view.categoryCombo);
        view.productNameCombo.setEditable(true);

        view.generateSkuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                SKUGenerator sku = new SKUGenerator();
                if (view.productNameCombo.getSelectedItem() == null) {
                    return;
                }
                try {
                    String generateSKU = sku.generateSKU((String) view.brandCombo.getSelectedItem(), (String) view.categoryCombo.getSelectedItem(), (String) view.productNameCombo.getSelectedItem());
                    view.skuField.setText(generateSKU);
                } catch (SQLException ex) {
                    Logger.getLogger(PosMain.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        view.calcTotalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (view.unitPriceField.getText() == null || view.unitPriceField.getText().isEmpty()) {
                    return;
                }

                String discount = view.discountField.getText();
                String priceTxtValue = view.unitPriceField.getText();
                String quantity = view.quantityField.getText();
                String xtaxRate = view.taxRateField.getText();

                double price = 0;
                double qty = 0;
                double discountPercent = 0;
                double taxRate = 0;
                double totalBeforeDiscount = 0;
                double discountAmount = 0;
                double totalAfterDiscount = 0;
                double taxAmount = 0;
                double finalTotal = 0;

                try {
                    price = Double.parseDouble(priceTxtValue); // Tax-exclusive unit price
                    qty = Double.parseDouble(quantity);

                    if (discount != null && !discount.isEmpty()) {
                        discountPercent = Double.parseDouble(discount);
                    }

                    if (xtaxRate != null && !xtaxRate.isEmpty()) {
                        taxRate = Double.parseDouble(xtaxRate);
                    }

                    // 1. Calculate base amount
                    totalBeforeDiscount = price * qty;

                    // 2. Calculate discount
                    discountAmount = totalBeforeDiscount * discountPercent / 100;
                    totalAfterDiscount = totalBeforeDiscount - discountAmount;

                    // 3. Calculate tax on discounted amount
                    taxAmount = totalAfterDiscount * taxRate / 100;

                    // 4. Final total
                    finalTotal = totalAfterDiscount + taxAmount;

                    // Optional Debug Logs
                    // System.out.println("Base: " + totalBeforeDiscount);
                    // System.out.println("Discount: " + discountAmount);
                    // System.out.println("After Discount: " + totalAfterDiscount);
                    // System.out.println("Tax: " + taxAmount);
                    // System.out.println("Final Total: " + finalTotal);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid number format in price, quantity, discount, or tax.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String total = String.format("%.2f", finalTotal);
                view.totalField.setText(total);

            }
        });

    }

    public void SaveDetails() throws SQLException {
        String invoiceNo = view.invoiceNoField.getText();
        String productName = (String) view.productNameCombo.getSelectedItem();
        String brand = (String) view.brandCombo.getSelectedItem();
        String category = (String) view.categoryCombo.getSelectedItem();
        String unit = (String) view.unitCombo.getSelectedItem();
        String sku = view.skuField.getText();
        String barcode = view.barcodeField.getText();
        String isTaxable = (String) view.isTaxableCombo.getSelectedItem();
        String taxRateStr = view.taxRateField.getText();
        String unitPriceStr = view.unitPriceField.getText();
        String quantityStr = view.quantityField.getText();
        String discountStr = view.discountField.getText();
        String totalStr = view.totalField.getText(); // Note: you had a typo in JTexablestField

// Optionally parse numeric values
        double taxRate = Double.parseDouble(taxRateStr);
        double unitPrice = Double.parseDouble(unitPriceStr);
        int quantity = Integer.parseInt(quantityStr);
        double discount = Double.parseDouble(discountStr);
        double total = Double.parseDouble(totalStr);

        Product product = new Product();
        product.setSku(view.skuField.getText().trim());
        String barcode1 = view.barcodeField.getText().trim();
        product.setBarcode(barcode1.isEmpty() ? null : barcode1);

        product.setName((String) view.productNameCombo.getSelectedItem());

        // Mapping category/brand name to ID using provided maps
        String categoryName = (String) view.categoryCombo.getSelectedItem();
        Integer categoryId = new CategoryService(DBConnection.getConnection()).getCategoryIdByName(categoryName);
        product.setCategoryId(categoryId);

        String brandName = (String) view.brandCombo.getSelectedItem();
        Integer brandId = new BrandService(DBConnection.getConnection()).getBrandIdByName(brandName);
        product.setBrandId(brandId);
        product.setHsnCode(view.hsnField.getText());
        product.setUnit((String) view.unitCombo.getSelectedItem());
        product.setPrice(new BigDecimal(view.unitPriceField.getText().trim()));
        product.setIsTaxable((String) view.isTaxableCombo.getSelectedItem());
        product.setTaxRate(new BigDecimal(view.taxRateField.getText().trim()));
        Timestamp createdAt = Timestamp.from(Instant.now());
        product.setCreatedAt(createdAt);
        product.setStatus("AVAILABLE");
        Integer productId = 0;
        ProductService ps = new ProductService(DBConnection.getConnection());
        boolean skuExists = ps.isSkuExists(sku);
        if (skuExists) {
            productId = ps.getProductIdBySku(sku);
        } else {
            boolean addProduct = ps.addProduct(product);
            if (addProduct) {
                productId = ps.getProductIdBySku(sku);
            } else {
                return;
            }
        }
        int purchaseId = new PurchaseService().getPurchaseIdByInvoiceNumber(invoiceNo);

        PurchaseItem pi = new PurchaseItem();
        pi.setProductId(productId);
        pi.setPurchaseId(purchaseId);
        pi.setQuantity(new BigDecimal(quantity));
        pi.setDiscount(new BigDecimal(discount));
        pi.setCostPrice(new BigDecimal(unitPrice));
        List<PurchaseItem> items = new ArrayList<>();
        items.add(pi); // Add the single PurchaseItem to the list
        int id = 0;
        List<PurchaseItem> addedItems = new PurchaseItemService().addPurchaseItems(items);
        for (PurchaseItem addedItem : addedItems) {
            id = addedItem.getId();
            break;
        }
        new StockService().upsertStock(productId, new BigDecimal(quantity));
        InventoryBatch ivb = new InventoryBatch();
        ivb.setProductId(productId);
        ivb.setPurchaseId(purchaseId);
        ivb.setQuantity(new BigDecimal(quantity));
        ivb.setCostPrice(new BigDecimal(unitPrice));
        ivb.setDiscount(new BigDecimal(discount));
        ivb.setCreatedAt(createdAt);
        InventoryBatchService ivbs = new InventoryBatchService(DBConnection.getConnection());
        List<InventoryBatch> batchList = new ArrayList<>();
        batchList.add(ivb);
        ivbs.addInventoryBatches(batchList, DBConnection.getConnection());

        JOptionPane.showMessageDialog(view, "added successfully");
        pc.loadDetailsTable(invoiceNo);

        BigDecimal calculateTotalAmount = CalculationUtil.calculateTotalAmount(new BigDecimal(unitPrice), new BigDecimal(quantity), new BigDecimal(discount));

        new PurchaseService().addToTotalAmountByInvoice(invoiceNo, calculateTotalAmount.doubleValue());
        pc.loadinvoiceTable();

    }

}
