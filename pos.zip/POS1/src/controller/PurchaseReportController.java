/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import model.Purchase;
import pos1.AddSingleProduct;
import pos1.DBConnection;
import pos1.PurchaseReport;
import pos1.UserManager;
import service.FakePurchaseService;
import service.PurchaseService;
import sun.nio.cs.ext.Big5;

/**
 *
 * @author sgjohn
 */
public class PurchaseReportController {

    PurchaseReport view;
    private String invoice_no = "";
    private String u;

    public PurchaseReportController(PurchaseReport view) {
        this.view = view;
        u = UserManager.getInstance().getCurrentUser().getUsername();
        loadinvoiceTable();

        view.summaryTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = view.summaryTable.getSelectedRow();
                if (row >= 0) {
                    view.summaryTable.scrollRectToVisible(view.summaryTable.getCellRect(row, 0, true));
                    Object invoice = view.summaryTable.getValueAt(row, 1);
                    if (invoice != null) {
                        loadDetailsTable(invoice.toString());
                        this.invoice_no = invoice.toString();
                    }
                }
            }
        });

        view.addItemButton.addActionListener(e -> {
            addSingleProductToDB();
        });
        view.deleteItemButton.addActionListener(e -> {
            int selectedRow = view.detailTable.getSelectedRow();
            if (selectedRow >= 0) {
                Object id = view.detailTable.getValueAt(selectedRow, 3);
                Object qty = view.detailTable.getValueAt(selectedRow, 4);
                int id1 = Integer.parseInt(id.toString());
                BigDecimal qty1 = new BigDecimal(qty.toString());
                deleteProduct(id1, qty1);
            }

        });

    }

    public void loadinvoiceTable() {
        System.out.println("=== loadInvoiceTable() triggered ===");

        try {
            // Step 1: Read filters
            String supplierName = (String) view.supplierComboBox.getSelectedItem();
            String searchKeyword = view.searchField.getText().trim();
            Date utilFromDate = view.fromDateChooser.getDate();
            Date utilToDate = view.toDateChooser.getDate();

            System.out.println("Selected supplier: " + supplierName);
            System.out.println("Search keyword: '" + searchKeyword + "'");
            System.out.println("From date: " + utilFromDate);
            System.out.println("To date: " + utilToDate);

            // Step 2: Convert to SQL Date
            java.sql.Date sqlFromDate = null;

            java.sql.Date sqlToDate = null;
            if (utilFromDate != null) {
                sqlFromDate = new java.sql.Date(utilFromDate.getTime());
            }

            if (utilToDate != null) {
                sqlToDate = new java.sql.Date(utilToDate.getTime());
            }
            List<Object[]> purchases = null;
            // Step 3: Call service
            if (!u.equals("admin1")) {
                PurchaseService ps = new PurchaseService();
                purchases = ps.getFilteredPurchases(sqlFromDate, sqlToDate, supplierName, searchKeyword);
            } else {
                FakePurchaseService ps = new FakePurchaseService();
                purchases = ps.getFilteredPurchases(sqlFromDate, sqlToDate, supplierName, searchKeyword);
            }

            System.out.println("Purchases fetched: " + purchases.size());

            // Step 4: Table model check
            DefaultTableModel tableModel = (DefaultTableModel) view.summaryTable.getModel();
            System.out.println("Table model class: " + tableModel.getClass().getName());

            if (!(tableModel instanceof DefaultTableModel)) {
                throw new IllegalStateException("summaryTable model is not a DefaultTableModel");
            }

            // Step 5: Populate table
            DefaultTableModel model = (DefaultTableModel) tableModel;
            model.setRowCount(0);
            for (Object[] row : purchases) {
                model.addRow(row);
            }
            view.computeInvoiceSummary();

            System.out.println("Table successfully populated.");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(view, "Failed to load purchase data: " + e.getMessage());
        }
    }

    public void loadDetailsTable(String inv) {
        List<Object[]> purchaseItems = null;

        if (!u.equals("admin1")) {
            PurchaseService ps = new PurchaseService();
            purchaseItems = ps.getPurchaseItemsForJTable(inv);
        } else {
            FakePurchaseService ps = new FakePurchaseService();
            purchaseItems = ps.getPurchaseItemsForJTable(inv);
        }
        // Updated column names: added Subtotal
        String[] columnNames = {"Product Name", "Brand Name", "Category Name", "Id", "Quantity", "Cost Price", "Discount", "Subtotal(incl Tax)"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        for (Object[] row : purchaseItems) {
            String productName = (String) row[0];
            String brandName = (String) row[1];
            String category = (String) row[2];
            String id = row[3].toString();
            int quantity = (int) Double.parseDouble(row[4].toString());

            double cost = Double.parseDouble(row[5].toString());
            double discount = Double.parseDouble(row[6].toString());

            double subtotal = quantity * cost * (1 - discount / 100.0);
            subtotal += subtotal * (18 / 100.0);
            tableModel.addRow(new Object[]{
                productName, brandName, category, id, quantity, cost, discount, subtotal
            });
        }

        view.detailTable.setModel(tableModel);  // Set model first
        view.computeDetailSummary();            // Then compute summary
    }

    private void addSingleProductToDB() {
        JOptionPane.showMessageDialog(view, "This will add product in the invoice no " + invoice_no);
        AddSingleProduct addSingleProduct = new AddSingleProduct();
        addSingleProduct.setVisible(true);
        new SingleProductController(invoice_no, addSingleProduct, PurchaseReportController.this);
    }

    private void deleteProduct(int id, BigDecimal qty) {
        //  new DeleteProductController(id,invoice_no,qty,PurchaseReportController.this);
        JOptionPane.showMessageDialog(view, "Item cannot be deleted");
    }

}
