/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import pos1.DBConnection;
import service.ProductService;
import service.PurchaseService;

/**
 *
 * @author sgjohn
 */
public class DeleteProductController {

    int id;
    String invoice_no;
    PurchaseReportController pc;
    private int purchaseId;
    private Integer productId;
     BigDecimal qty;
  

    DeleteProductController(Integer id, String invoice_no, BigDecimal qty, PurchaseReportController pc) {
         this.id = id;
        this.pc = pc;
        this.invoice_no = invoice_no;
        this.qty=qty;
        deleteFromDB();
    }

    private void deleteFromDB() {
        PurchaseService ps = new PurchaseService();
        try {
            purchaseId = ps.getPurchaseIdByInvoiceNumber(invoice_no);
           
        } catch (SQLException ex) {
            Logger.getLogger(DeleteProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    
    
}
