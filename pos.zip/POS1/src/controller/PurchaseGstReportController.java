package controller;

import pos1.PurchaseGstReportView;
import service.PurchaseGSTService;
import model.PurchaseGST;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class PurchaseGstReportController {
    private final PurchaseGstReportView view;
    private final PurchaseGSTService service;

    public PurchaseGstReportController(PurchaseGstReportView view, PurchaseGSTService service) {
        this.view = view;
        this.service = service;
        initController();
    }

    private void initController() {
        view.btnGenerate.addActionListener(e -> loadData());
        view.btnExportCsv.addActionListener(e -> exportToCsv());
    }

    private void loadData() {
        LocalDate from = null, to = null;
        if (view.fromDateChooser.getDate() != null) {
            from = view.fromDateChooser.getDate().toInstant()
                        .atZone(java.time.ZoneId.systemDefault())
                        .toLocalDate();
        }
        if (view.toDateChooser.getDate() != null) {
            to = view.toDateChooser.getDate().toInstant()
                        .atZone(java.time.ZoneId.systemDefault())
                        .toLocalDate();
        }

        // Fetch data with date filtering at service level
        List<PurchaseGST> filtered = service.getPurchasesByDate(from, to);

        populateTable(filtered);
        updateSummary(filtered);
    }

    private void populateTable(List<PurchaseGST> list) {
        DefaultTableModel model = (DefaultTableModel) view.table.getModel();
        model.setRowCount(0);
        for (PurchaseGST p : list) {
            model.addRow(new Object[]{
                p.getInvoiceNumber(),
                p.getPurchaseDate(),
                p.getSupplierName(),
                p.getProductName(),
                p.getQuantity(),
                p.getCostPrice(),
                p.getDiscount(),
                p.getTaxableValue(),
                p.getTaxRate(),
                p.getCgstAmount(),
                p.getSgstAmount(),
                p.getTotalTaxAmount(),
                p.getTotalValue()
            });
        }
    }

    private void updateSummary(List<PurchaseGST> list) {
        BigDecimal totalTaxable = BigDecimal.ZERO;
        BigDecimal totalCgst = BigDecimal.ZERO;
        BigDecimal totalSgst = BigDecimal.ZERO;
        BigDecimal totalTax = BigDecimal.ZERO;
        BigDecimal grandTotal = BigDecimal.ZERO;

        for (PurchaseGST p : list) {
            totalTaxable = totalTaxable.add(p.getTaxableValue());
            totalCgst = totalCgst.add(p.getCgstAmount());
            totalSgst = totalSgst.add(p.getSgstAmount());
            totalTax = totalTax.add(p.getTotalTaxAmount());
            grandTotal = grandTotal.add(p.getTotalValue());
        }

        view.lblTotalTaxableValue.setText("Total Taxable: ₹ " + totalTaxable);
        view.lblTotalCgst.setText("Total CGST: " + totalCgst);
        view.lblTotalSgst.setText("Total SGST: " + totalSgst);
        view.lblTotalTax.setText("Total Tax: " + totalTax);
        view.lblTotalInvoiceValue.setText("Grand Total: " + grandTotal);
    }

    private void exportToCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save CSV");
        chooser.setFileFilter(new FileNameExtensionFilter("CSV files", "csv"));
        if (chooser.showSaveDialog(view) == JFileChooser.APPROVE_OPTION) {
            String path = chooser.getSelectedFile().getAbsolutePath();
            if (!path.endsWith(".csv")) path += ".csv";
            try (FileWriter writer = new FileWriter(path)) {
                DefaultTableModel model = (DefaultTableModel) view.table.getModel();
                for (int i = 0; i < model.getColumnCount(); i++) {
                    writer.append(model.getColumnName(i))
                          .append(i < model.getColumnCount() - 1 ? "," : "\n");
                }
                for (int r = 0; r < model.getRowCount(); r++) {
                    for (int c = 0; c < model.getColumnCount(); c++) {
                        writer.append(String.valueOf(model.getValueAt(r, c)))
                              .append(c < model.getColumnCount() - 1 ? "," : "\n");
                    }
                }
                JOptionPane.showMessageDialog(view, "CSV exported successfully.");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(view, "Error exporting CSV: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        PurchaseGstReportView view = new PurchaseGstReportView();
        PurchaseGSTService service = new PurchaseGSTService();
        new PurchaseGstReportController(view, service);
    }
}
