/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import model.Category;
import pos1.DBConnection;
import service.CategoryService;

/**
 *
 * @author sgjohn
 */
public class CategoryController {

    private Connection conn;

   public void addCategory(String name, String description) {
        try {
            Category category = new Category();
            category.setName(name);
            category.setDescription(description);

            conn = DBConnection.getConnection();
            CategoryService cs = new CategoryService(conn);
            boolean added = cs.addCategory(category);

            if (added) {
                JOptionPane.showMessageDialog(null, "Category added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add category.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            Logger.getLogger(CategoryController.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadCategories(JComboBox<String> categoryCombo) {
        try {
            conn = DBConnection.getConnection();
            CategoryService cs =new CategoryService(conn);
            List<Category> allCategories = cs.getAllCategories();
            // Clear existing items
        categoryCombo.removeAllItems();

        // Optional: Add a prompt item
        categoryCombo.addItem("");

        // Add category names
        for (Category category : allCategories) {
            categoryCombo.addItem(category.getName()); // Assuming Category has getName()
        }
        } catch (SQLException ex) {
            Logger.getLogger(CategoryController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
}
