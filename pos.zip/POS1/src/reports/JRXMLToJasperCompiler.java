/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reports;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import net.sf.jasperreports.engine.JasperCompileManager;


public class JRXMLToJasperCompiler {

    public static void main(String[] args) {
        try {
            // Path to your JRXML file
            String jrxmlPath = "src/reports/print.jrxml";
            // Output path for compiled JASPER file
            String jasperPath = "print.jasper";

            // Compile the JRXML to JASPER
            JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);

            System.out.println("Compilation successful: " + jasperPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}