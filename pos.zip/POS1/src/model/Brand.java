/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class Brand {
    private int id;
    private String name;

    // Default constructor
    public Brand() {
    }

    // Parameterized constructor
    public Brand(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Constructor without ID (for inserts before auto-generation)
    public Brand(String name) {
        this.name = name;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // toString method (useful for debugging or combo boxes)
    @Override
    public String toString() {
        return name;
    }
}
