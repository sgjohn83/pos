/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author sgjohn
 */
import java.math.BigDecimal;
import java.time.LocalDate;

public class PurchaseGST {

    private int purchaseId;
    private String invoiceNumber;
    private LocalDate purchaseDate;
    private String supplierName;
    private String productName;
    private BigDecimal quantity;
    private BigDecimal costPrice;
    private BigDecimal discount;
    private BigDecimal taxableValue;
    private BigDecimal taxRate;
    private BigDecimal cgstAmount;  // Added back
    private BigDecimal sgstAmount;  // Added back
    private BigDecimal totalTaxAmount;  // Combined tax (CGST + SGST)
    private BigDecimal totalValue;

    // Getters and Setters

    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getCostPrice() {
        return costPrice;
    }

    public void setCostPrice(BigDecimal costPrice) {
        this.costPrice = costPrice;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public BigDecimal getTaxableValue() {
        return taxableValue;
    }

    public void setTaxableValue(BigDecimal taxableValue) {
        this.taxableValue = taxableValue;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }

    public BigDecimal getCgstAmount() {
        return cgstAmount;
    }

    public void setCgstAmount(BigDecimal cgstAmount) {
        this.cgstAmount = cgstAmount;
    }

    public BigDecimal getSgstAmount() {
        return sgstAmount;
    }

    public void setSgstAmount(BigDecimal sgstAmount) {
        this.sgstAmount = sgstAmount;
    }

    public BigDecimal getTotalTaxAmount() {
        return totalTaxAmount;
    }

    public void setTotalTaxAmount(BigDecimal totalTaxAmount) {
        this.totalTaxAmount = totalTaxAmount;
    }

    public BigDecimal getTotalValue() {
        return totalValue;
    }

    public void setTotalValue(BigDecimal totalValue) {
        this.totalValue = totalValue;
    }

    // Helper method to calculate CGST, SGST, tax amount and total value
    public void calculateTaxAndTotal() {
        if (taxableValue != null && taxRate != null) {
            BigDecimal tax = taxableValue.multiply(taxRate).divide(BigDecimal.valueOf(100));  // Combined tax amount
            cgstAmount = tax.divide(BigDecimal.valueOf(2));  // CGST is half of total tax
            sgstAmount = tax.divide(BigDecimal.valueOf(2));  // SGST is half of total tax
            totalTaxAmount = cgstAmount.add(sgstAmount);  // Total tax = CGST + SGST
            totalValue = taxableValue.add(totalTaxAmount);  // Total value including tax
        }
    }
}
