/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author sgjohn
 */


import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class Purchase {

    private int id;
    private int supplierId;
    private String invoiceNumber;
    private Date purchaseDate;
    private BigDecimal totalAmount;
    private Integer createdBy; // Nullable field
    private Timestamp createdAt;

    // Constructors
    public Purchase() {}

    public Purchase(int id, int supplierId, String invoiceNumber, Date purchaseDate,
                    BigDecimal totalAmount, Integer createdBy, Timestamp createdAt) {
        this.id = id;
        this.supplierId = supplierId;
        this.invoiceNumber = invoiceNumber;
        this.purchaseDate = purchaseDate;
        this.totalAmount = totalAmount;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    // toString
    @Override
    public String toString() {
        return "Purchase{" +
                "id=" + id +
                ", supplierId=" + supplierId +
                ", invoiceNumber='" + invoiceNumber + '\'' +
                ", purchaseDate=" + purchaseDate +
                ", totalAmount=" + totalAmount +
                ", createdBy=" + createdBy +
                ", createdAt=" + createdAt +
                '}';
    }
}
