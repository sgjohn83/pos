/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author sgjohn
 */
public class ProductSummary {
    private String brandName;
    private String categoryName;
    private String productName;
    private String unit;
    private String sku;
    private String barcode;
    private String isTaxable;
    private String taxRate;
    private double price;
    private double discount;
    private int quantity;
    private double total;
    private String hsnCode;

    // Constructors
    public ProductSummary() {}

    public ProductSummary(String brandName, String categoryName, String productName, String unit,
                          String sku, String barcode, String isTaxable, String taxRate,
                          double price, int quantity, double discount, double total, String hsnCode) {
        this.brandName = brandName;
        this.categoryName = categoryName;
        this.productName = productName;
        this.unit = unit;
        this.sku = sku;
        this.barcode = barcode;
        this.isTaxable = isTaxable;
        this.taxRate = taxRate;
        this.price = price;
        this.quantity = quantity;
        this.total = total;
        this.discount = discount;
        this.hsnCode = hsnCode;
    }

    // Getters and setters
    public String getBrandName() { return brandName; }
    public void setBrandName(String brandName) { this.brandName = brandName; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }

    public String getBarcode() { return barcode; }
    public void setBarcode(String barcode) { this.barcode = barcode; }

    public String getIsTaxable() { return isTaxable; }
    public void setIsTaxable(String isTaxable) { this.isTaxable = isTaxable; }

    public String getTaxRate() { return taxRate; }
    public void setTaxRate(String taxRate) { this.taxRate = taxRate; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }

    public String getHsnCode() { return hsnCode; }
    public void setHsnCode(String hsnCode) { this.hsnCode = hsnCode; }

    @Override
    public String toString() {
        return productName + " (" + quantity + " @ " + price + ") = " + total + " [HSN: " + hsnCode + "]";
    }
}
