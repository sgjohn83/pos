/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author sgjohn
 */
import java.math.BigDecimal;
import java.sql.Timestamp;

public class Stock {
    private int id;
    private Product product;          // Reference to Product object
    private BigDecimal quantity;
    private Timestamp lastUpdated;

    // Constructors
    public Stock() {}

    public Stock(int id, Product product, BigDecimal quantity, Timestamp lastUpdated) {
        this.id = id;
        this.product = product;
        this.quantity = quantity;
        this.lastUpdated = lastUpdated;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}

