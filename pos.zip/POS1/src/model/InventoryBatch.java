package model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

/**
 * Represents a batch of inventory for a specific product and purchase record.
 */
public class InventoryBatch {

    private int id;
    private int productId;
    private int purchaseId;
    private BigDecimal quantity;
    private BigDecimal costPrice;
    private Timestamp createdAt;
    private BigDecimal discount; // New field

    // Default constructor
    public InventoryBatch() {}

    // Parameterized constructor
    public InventoryBatch(int id, int productId, int purchaseId, BigDecimal quantity, BigDecimal costPrice, Timestamp createdAt, BigDecimal discount) {
        this.id = id;
        this.productId = productId;
        this.purchaseId = purchaseId;
        this.quantity = quantity;
        this.costPrice = costPrice;
        this.createdAt = createdAt;
        this.discount = discount;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getCostPrice() {
        return costPrice;
    }

    public void setCostPrice(BigDecimal costPrice) {
        this.costPrice = costPrice;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    @Override
    public String toString() {
        return "InventoryBatch{" +
                "id=" + id +
                ", productId=" + productId +
                ", purchaseId=" + purchaseId +
                ", quantity=" + quantity +
                ", costPrice=" + costPrice +
                ", createdAt=" + createdAt +
                ", discount=" + discount +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InventoryBatch)) return false;
        InventoryBatch that = (InventoryBatch) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
