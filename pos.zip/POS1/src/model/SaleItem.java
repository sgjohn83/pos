/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author sgjohn
 */
import java.math.BigDecimal;

public class SaleItem {
    private int id;
    private Sales sale;         // Reference to Sales object
    private Product product;    // Reference to Product object
    private BigDecimal quantity;
    private BigDecimal price;
    private BigDecimal taxRate;

    // Constructors
    public SaleItem() {}

    public SaleItem(int id, Sales sale, Product product, BigDecimal quantity, BigDecimal price, BigDecimal taxRate) {
        this.id = id;
        this.sale = sale;
        this.product = product;
        this.quantity = quantity;
        this.price = price;
        this.taxRate = taxRate;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Sales getSale() {
        return sale;
    }

    public void setSale(Sales sale) {
        this.sale = sale;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }
}
