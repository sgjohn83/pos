package model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Product {

    private int id;
    private String sku;
    private String barcode;
    private String name;
    private String hsnCode; // ✅ New field
    private int categoryId;
    private Integer brandId; // Nullable
    private String unit;
    private BigDecimal price;
    private String isTaxable; // "YES" or "NO"
    private BigDecimal taxRate;
    private String status; // "AVAILABLE" or "NOT AVAILABLE"
    private Timestamp createdAt;

    public Product() {
    }

    public Product(int id, String sku, String barcode, String name, String hsnCode,
                   int categoryId, Integer brandId, String unit, BigDecimal price,
                   String isTaxable, BigDecimal taxRate, String status, Timestamp createdAt) {
        this.id = id;
        this.sku = sku;
        this.barcode = barcode;
        this.name = name;
        this.hsnCode = hsnCode;
        this.categoryId = categoryId;
        this.brandId = brandId;
        this.unit = unit;
        this.price = price;
        this.isTaxable = isTaxable;
        this.taxRate = taxRate;
        this.status = status;
        this.createdAt = createdAt;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHsnCode() {
        return hsnCode;
    }

    public void setHsnCode(String hsnCode) {
        this.hsnCode = hsnCode;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getIsTaxable() {
        return isTaxable;
    }

    public void setIsTaxable(String isTaxable) {
        this.isTaxable = isTaxable;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return name + " (" + sku + ")";
    }
}
